window.skins=window.skins||{};
                function __extends(d, b) {
                    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
                        function __() {
                            this.constructor = d;
                        }
                    __.prototype = b.prototype;
                    d.prototype = new __();
                };
                window.generateEUI = {};
                generateEUI.paths = {};
                generateEUI.styles = undefined;
                generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","eui.CheckBox":"resource/eui_skins/CheckBoxSkin.exml","eui.HScrollBar":"resource/eui_skins/HScrollBarSkin.exml","eui.HSlider":"resource/eui_skins/HSliderSkin.exml","eui.Panel":"resource/eui_skins/PanelSkin.exml","eui.TextInput":"resource/eui_skins/TextInputSkin.exml","eui.RadioButton":"resource/eui_skins/RadioButtonSkin.exml","eui.Scroller":"resource/eui_skins/ScrollerSkin.exml","eui.ToggleSwitch":"resource/eui_skins/ToggleSwitchSkin.exml","eui.VScrollBar":"resource/eui_skins/VScrollBarSkin.exml","eui.VSlider":"resource/eui_skins/VSliderSkin.exml","eui.ItemRenderer":"resource/eui_skins/ItemRendererSkin.exml","SceneBegin":"resource/scene/SceneBegin.exml","SceneGame":"resource/scene/SceneGame.exml","menu":"resource/eui_skins/menu.exml","pause_panel":"resource/eui_skins/pause_panel.exml","Begin_inter":"resource/eui_skins/Begin_inter.exml","main_interface2":"resource/eui_skins/main_interface2.exml","menu_new":"resource/eui_skins/menu_new.exml"};generateEUI.paths['resource/eui_skins/Begin_inter.exml'] = window.Begin_interSkin = (function (_super) {
	__extends(Begin_interSkin, _super);
	function Begin_interSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 1080;
		this.width = 1920;
	}
	var _proto = Begin_interSkin.prototype;

	return Begin_interSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "hanti";
		t.left = 8;
		t.right = 8;
		t.size = 30;
		t.textAlign = "center";
		t.textColor = 0x000000;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function (_super) {
	__extends(CheckBoxSkin, _super);
	function CheckBoxSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","c_on_png")
				])
			,
			new eui.State ("downAndSelected",
				[
				])
			,
			new eui.State ("disabledAndSelected",
				[
				])
		];
	}
	var _proto = CheckBoxSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.fillMode = "scale";
		t.height = 40;
		t.source = "c_off_png";
		t.width = 62.5;
		return t;
	};
	return CheckBoxSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function (_super) {
	__extends(HScrollBarSkin, _super);
	function HScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = HScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 8;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.verticalCenter = 0;
		t.width = 30;
		return t;
	};
	return HScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HSliderSkin.exml'] = window.skins.HSliderSkin = (function (_super) {
	__extends(HSliderSkin, _super);
	function HSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = HSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.height = 6;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_sb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.source = "thumb_png";
		t.verticalCenter = 0;
		return t;
	};
	return HSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ItemRendererSkin.exml'] = window.skins.ItemRendererSkin = (function (_super) {
	__extends(ItemRendererSkin, _super);
	function ItemRendererSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data"],[0],this.labelDisplay,"text");
	}
	var _proto = ItemRendererSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ItemRendererSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/LabelSkin.exml'] = window.LabelSkin = (function (_super) {
	__extends(LabelSkin, _super);
	function LabelSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.height = 30;
		this.width = 40;
		this.elementsContent = [this.labelDisplay_i()];
	}
	var _proto = LabelSkin.prototype;

	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "hanti";
		t.left = 8;
		t.right = 8;
		t.size = 30;
		t.textAlign = "center";
		t.textColor = 0x000000;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return LabelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/loading.exml'] = window.loading = (function (_super) {
	__extends(loading, _super);
	function loading() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 1080;
		this.width = 1920;
		this.elementsContent = [this._Image1_i()];
	}
	var _proto = loading.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "preloading_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	return loading;
})(eui.Skin);generateEUI.paths['resource/eui_skins/main_interface2.exml'] = window.main_interfaceSkin = (function (_super) {
	__extends(main_interfaceSkin, _super);
	var main_interfaceSkin$Skin1 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin1, _super);
		function main_interfaceSkin$Skin1() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin1.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin1;
	})(eui.Skin);

	var main_interfaceSkin$Skin2 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin2, _super);
		function main_interfaceSkin$Skin2() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin2.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "caozuo_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin2;
	})(eui.Skin);

	var main_interfaceSkin$Skin3 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin3, _super);
		function main_interfaceSkin$Skin3() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin3.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "newgame_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin3;
	})(eui.Skin);

	var main_interfaceSkin$Skin4 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin4, _super);
		function main_interfaceSkin$Skin4() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin4.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin4;
	})(eui.Skin);

	var main_interfaceSkin$Skin5 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin5, _super);
		function main_interfaceSkin$Skin5() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin5.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_button_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin5;
	})(eui.Skin);

	var main_interfaceSkin$Skin6 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin6, _super);
		function main_interfaceSkin$Skin6() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin6.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "setting_button_png";
			t.percentWidth = 100;
			return t;
		};
		return main_interfaceSkin$Skin6;
	})(eui.Skin);

	var main_interfaceSkin$Skin7 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin7, _super);
		function main_interfaceSkin$Skin7() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin7.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "collection_button_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin7;
	})(eui.Skin);

	var main_interfaceSkin$Skin8 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin8, _super);
		function main_interfaceSkin$Skin8() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin8.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "quit_button_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin8;
	})(eui.Skin);

	var main_interfaceSkin$Skin9 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin9, _super);
		function main_interfaceSkin$Skin9() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin9.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "creator_button_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin9;
	})(eui.Skin);

	var main_interfaceSkin$Skin10 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin10, _super);
		function main_interfaceSkin$Skin10() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin10.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin10;
	})(eui.Skin);

	var main_interfaceSkin$Skin11 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin11, _super);
		function main_interfaceSkin$Skin11() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin11.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin11;
	})(eui.Skin);

	var main_interfaceSkin$Skin12 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin12, _super);
		function main_interfaceSkin$Skin12() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin12.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "queding_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin12;
	})(eui.Skin);

	var main_interfaceSkin$Skin13 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin13, _super);
		function main_interfaceSkin$Skin13() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin13.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin13;
	})(eui.Skin);

	var main_interfaceSkin$Skin14 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin14, _super);
		function main_interfaceSkin$Skin14() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin14.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "queding_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin14;
	})(eui.Skin);

	var main_interfaceSkin$Skin15 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin15, _super);
		function main_interfaceSkin$Skin15() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin15.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin15;
	})(eui.Skin);

	var main_interfaceSkin$Skin16 = 	(function (_super) {
		__extends(main_interfaceSkin$Skin16, _super);
		function main_interfaceSkin$Skin16() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = main_interfaceSkin$Skin16.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "start_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return main_interfaceSkin$Skin16;
	})(eui.Skin);

	function main_interfaceSkin() {
		_super.call(this);
		this.skinParts = ["enterStart","quitStart","enterSetting","quitSetting","enterSpec","quitSpec","enterNewgame","quitNewgame","enterCreator","quitCreator","enterCollec","quitCollec","enterQuitgame","quiQuitgame","music","voice_like","spec_return","specification","setting_enter","new_game","start_return","memo1_text","memo1","memo2_text","memo2","memo3_text","memo3","start_enter","start_game","setting","collection","quit","creator","main_layout","spec_detail_return","spec_enter","collection_return","collection_enter","sure_quit","quit_return","quit_enter","usr_name","name_queding","name_cancel","illegal","newgame_enter","creator_return","creator_enter","main_stack","end"];
		
		this.height = 1080;
		this.width = 1920;
		this.enterStart_i();
		this.quitStart_i();
		this.enterSetting_i();
		this.quitSetting_i();
		this.enterSpec_i();
		this.quitSpec_i();
		this.enterNewgame_i();
		this.quitNewgame_i();
		this.enterCreator_i();
		this.quitCreator_i();
		this.enterCollec_i();
		this.quitCollec_i();
		this.enterQuitgame_i();
		this.quiQuitgame_i();
		this.elementsContent = [this._Image1_i(),this.main_stack_i(),this.end_i()];
		
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object1,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object2,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object3,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object4,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, ["start_enter"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object6,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object7,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object8,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object9,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object10,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object11,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object11,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object12,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object13,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object13,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object14,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object14,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object15,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object15,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object16,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object16,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object17,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object17,"x");
		eui.Binding.$bindProperties(this, ["start_enter"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object18,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object18,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object19,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object19,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object20,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object20,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object21,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object21,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object22,"alpha");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object23,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object23,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object24,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object24,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object25,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object25,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object26,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object26,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object27,"alpha");
		eui.Binding.$bindProperties(this, ["setting_enter"],[0],this._TweenItem6,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object28,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object28,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object29,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object29,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object30,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object30,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object31,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object31,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object32,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object32,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object33,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object33,"x");
		eui.Binding.$bindProperties(this, ["setting_enter"],[0],this._TweenItem7,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object34,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object34,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object35,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object35,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object36,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object36,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object37,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object37,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object38,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object38,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem8,"target");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object39,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object39,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object40,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object40,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object41,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object41,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object42,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object42,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object43,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object43,"x");
		eui.Binding.$bindProperties(this, ["setting_enter"],[0],this._TweenItem9,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object44,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object44,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object45,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object45,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object46,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object46,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object47,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object47,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object48,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object48,"x");
		eui.Binding.$bindProperties(this, ["spec_enter"],[0],this._TweenItem10,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object49,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object49,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object50,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object50,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object51,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object51,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object52,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object52,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object53,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object53,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object54,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object54,"x");
		eui.Binding.$bindProperties(this, ["spec_enter"],[0],this._TweenItem11,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object55,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object55,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object56,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object56,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object57,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object57,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object58,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object58,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object59,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object59,"x");
		eui.Binding.$bindProperties(this, ["setting_enter"],[0],this._TweenItem12,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object60,"alpha");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object61,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object61,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object62,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object62,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object63,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object63,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object64,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object64,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object65,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object65,"x");
		eui.Binding.$bindProperties(this, ["start_enter"],[0],this._TweenItem13,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object66,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object66,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object67,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object67,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object68,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object68,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object69,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object69,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object70,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object70,"x");
		eui.Binding.$bindProperties(this, ["newgame_enter"],[0],this._TweenItem14,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object71,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object71,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object72,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object72,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object73,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object73,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object74,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object74,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object75,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object75,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object76,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object76,"x");
		eui.Binding.$bindProperties(this, ["newgame_enter"],[0],this._TweenItem15,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object77,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object77,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object78,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object78,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object79,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object79,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object80,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object80,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object81,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object81,"x");
		eui.Binding.$bindProperties(this, ["start_enter"],[0],this._TweenItem16,"target");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object82,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object82,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object83,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object83,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object84,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object84,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object85,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object85,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object86,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object86,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem17,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object87,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object87,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object88,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object88,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object89,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object89,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object90,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object90,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object91,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object91,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object92,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object92,"x");
		eui.Binding.$bindProperties(this, ["creator_enter"],[0],this._TweenItem18,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object93,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object93,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object94,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object94,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object95,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object95,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object96,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object96,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object97,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object97,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object98,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object98,"x");
		eui.Binding.$bindProperties(this, ["creator_enter"],[0],this._TweenItem19,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object99,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object99,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object100,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object100,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object101,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object101,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object102,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object102,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object103,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object103,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem20,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object104,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object104,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object105,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object105,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object106,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object106,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object107,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object107,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object108,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object108,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object109,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object109,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem21,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object110,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object110,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object111,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object111,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object112,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object112,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object113,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object113,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object114,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object114,"x");
		eui.Binding.$bindProperties(this, ["collection_enter"],[0],this._TweenItem22,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object115,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object115,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object116,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object116,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object117,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object117,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object118,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object118,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object119,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object119,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object120,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object120,"x");
		eui.Binding.$bindProperties(this, ["collection_enter"],[0],this._TweenItem23,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object121,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object121,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object122,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object122,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object123,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object123,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object124,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object124,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object125,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object125,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem24,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object126,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object126,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object127,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object127,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object128,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object128,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object129,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object129,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object130,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object130,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object131,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object131,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem25,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object132,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object132,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object133,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object133,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object134,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object134,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object135,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object135,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object136,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object136,"x");
		eui.Binding.$bindProperties(this, ["quit_enter"],[0],this._TweenItem26,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object137,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object137,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object138,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object138,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object139,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object139,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object140,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object140,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object141,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object141,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object142,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object142,"x");
		eui.Binding.$bindProperties(this, ["quit_enter"],[0],this._TweenItem27,"target");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object143,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object143,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object144,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object144,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object145,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object145,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object146,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object146,"x");
		eui.Binding.$bindProperties(this, [0],[],this._Object147,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object147,"x");
		eui.Binding.$bindProperties(this, ["main_layout"],[0],this._TweenItem28,"target");
		eui.Binding.$bindProperties(this, [0],[],this._Object148,"alpha");
		eui.Binding.$bindProperties(this, [250],[],this._Object148,"x");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object149,"alpha");
		eui.Binding.$bindProperties(this, [200],[],this._Object149,"x");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object150,"alpha");
		eui.Binding.$bindProperties(this, [150],[],this._Object150,"x");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object151,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object151,"x");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object152,"alpha");
		eui.Binding.$bindProperties(this, [50],[],this._Object152,"x");
		eui.Binding.$bindProperties(this, [1],[],this._Object153,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object153,"x");
	}
	var _proto = main_interfaceSkin.prototype;

	_proto.enterStart_i = function () {
		var t = new egret.tween.TweenGroup();
		this.enterStart = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Wait1_i(),this._Set1_i(),this._Wait2_i(),this._Set2_i(),this._Wait3_i(),this._Set3_i(),this._Wait4_i(),this._Set4_i(),this._Wait5_i(),this._Set5_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Set6_i(),this._Wait6_i(),this._Set7_i(),this._Wait7_i(),this._Set8_i(),this._Wait8_i(),this._Set9_i(),this._Wait9_i(),this._Set10_i(),this._Wait10_i(),this._Set11_i()];
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._Wait8_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait9_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._Wait10_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto.quitStart_i = function () {
		var t = new egret.tween.TweenGroup();
		this.quitStart = t;
		t.items = [this._TweenItem3_i(),this._TweenItem4_i()];
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set12_i(),this._Wait11_i(),this._Set13_i(),this._Wait12_i(),this._Set14_i(),this._Wait13_i(),this._Set15_i(),this._Wait14_i(),this._Set16_i(),this._Wait15_i(),this._Set17_i()];
		return t;
	};
	_proto._Set12_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._Wait11_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set13_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._Wait12_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set14_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._Wait13_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set15_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto._Wait14_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set16_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto._Wait15_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set17_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Wait16_i(),this._Set18_i(),this._Wait17_i(),this._Set19_i(),this._Wait18_i(),this._Set20_i(),this._Wait19_i(),this._Set21_i(),this._Wait20_i(),this._Set22_i()];
		return t;
	};
	_proto._Wait16_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set18_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._Wait17_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set19_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object19_i();
		return t;
	};
	_proto._Object19_i = function () {
		var t = {};
		this._Object19 = t;
		return t;
	};
	_proto._Wait18_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set20_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object20_i();
		return t;
	};
	_proto._Object20_i = function () {
		var t = {};
		this._Object20 = t;
		return t;
	};
	_proto._Wait19_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set21_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object21_i();
		return t;
	};
	_proto._Object21_i = function () {
		var t = {};
		this._Object21 = t;
		return t;
	};
	_proto._Wait20_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set22_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object22_i();
		return t;
	};
	_proto._Object22_i = function () {
		var t = {};
		this._Object22 = t;
		return t;
	};
	_proto.enterSetting_i = function () {
		var t = new egret.tween.TweenGroup();
		this.enterSetting = t;
		t.items = [this._TweenItem5_i(),this._TweenItem6_i()];
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Wait21_i(),this._Set23_i(),this._Wait22_i(),this._Set24_i(),this._Wait23_i(),this._Set25_i(),this._Wait24_i(),this._Set26_i(),this._Wait25_i(),this._Set27_i()];
		return t;
	};
	_proto._Wait21_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set23_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object23_i();
		return t;
	};
	_proto._Object23_i = function () {
		var t = {};
		this._Object23 = t;
		return t;
	};
	_proto._Wait22_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set24_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object24_i();
		return t;
	};
	_proto._Object24_i = function () {
		var t = {};
		this._Object24 = t;
		return t;
	};
	_proto._Wait23_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set25_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object25_i();
		return t;
	};
	_proto._Object25_i = function () {
		var t = {};
		this._Object25 = t;
		return t;
	};
	_proto._Wait24_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set26_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object26_i();
		return t;
	};
	_proto._Object26_i = function () {
		var t = {};
		this._Object26 = t;
		return t;
	};
	_proto._Wait25_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set27_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object27_i();
		return t;
	};
	_proto._Object27_i = function () {
		var t = {};
		this._Object27 = t;
		return t;
	};
	_proto._TweenItem6_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem6 = t;
		t.paths = [this._Set28_i(),this._Wait26_i(),this._Set29_i(),this._Wait27_i(),this._Set30_i(),this._Wait28_i(),this._Set31_i(),this._Wait29_i(),this._Set32_i(),this._Wait30_i(),this._Set33_i()];
		return t;
	};
	_proto._Set28_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object28_i();
		return t;
	};
	_proto._Object28_i = function () {
		var t = {};
		this._Object28 = t;
		return t;
	};
	_proto._Wait26_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set29_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object29_i();
		return t;
	};
	_proto._Object29_i = function () {
		var t = {};
		this._Object29 = t;
		return t;
	};
	_proto._Wait27_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set30_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object30_i();
		return t;
	};
	_proto._Object30_i = function () {
		var t = {};
		this._Object30 = t;
		return t;
	};
	_proto._Wait28_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set31_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object31_i();
		return t;
	};
	_proto._Object31_i = function () {
		var t = {};
		this._Object31 = t;
		return t;
	};
	_proto._Wait29_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set32_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object32_i();
		return t;
	};
	_proto._Object32_i = function () {
		var t = {};
		this._Object32 = t;
		return t;
	};
	_proto._Wait30_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set33_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object33_i();
		return t;
	};
	_proto._Object33_i = function () {
		var t = {};
		this._Object33 = t;
		return t;
	};
	_proto.quitSetting_i = function () {
		var t = new egret.tween.TweenGroup();
		this.quitSetting = t;
		t.items = [this._TweenItem7_i(),this._TweenItem8_i()];
		return t;
	};
	_proto._TweenItem7_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem7 = t;
		t.paths = [this._Wait31_i(),this._Set34_i(),this._Wait32_i(),this._Set35_i(),this._Wait33_i(),this._Set36_i(),this._Wait34_i(),this._Set37_i(),this._Wait35_i(),this._Set38_i()];
		return t;
	};
	_proto._Wait31_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set34_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object34_i();
		return t;
	};
	_proto._Object34_i = function () {
		var t = {};
		this._Object34 = t;
		return t;
	};
	_proto._Wait32_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set35_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object35_i();
		return t;
	};
	_proto._Object35_i = function () {
		var t = {};
		this._Object35 = t;
		return t;
	};
	_proto._Wait33_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set36_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object36_i();
		return t;
	};
	_proto._Object36_i = function () {
		var t = {};
		this._Object36 = t;
		return t;
	};
	_proto._Wait34_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set37_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object37_i();
		return t;
	};
	_proto._Object37_i = function () {
		var t = {};
		this._Object37 = t;
		return t;
	};
	_proto._Wait35_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set38_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object38_i();
		return t;
	};
	_proto._Object38_i = function () {
		var t = {};
		this._Object38 = t;
		return t;
	};
	_proto._TweenItem8_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem8 = t;
		t.paths = [this._Wait36_i(),this._Set39_i(),this._Wait37_i(),this._Set40_i(),this._Wait38_i(),this._Set41_i(),this._Wait39_i(),this._Set42_i(),this._Wait40_i(),this._Set43_i()];
		return t;
	};
	_proto._Wait36_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set39_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object39_i();
		return t;
	};
	_proto._Object39_i = function () {
		var t = {};
		this._Object39 = t;
		return t;
	};
	_proto._Wait37_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set40_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object40_i();
		return t;
	};
	_proto._Object40_i = function () {
		var t = {};
		this._Object40 = t;
		return t;
	};
	_proto._Wait38_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set41_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object41_i();
		return t;
	};
	_proto._Object41_i = function () {
		var t = {};
		this._Object41 = t;
		return t;
	};
	_proto._Wait39_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set42_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object42_i();
		return t;
	};
	_proto._Object42_i = function () {
		var t = {};
		this._Object42 = t;
		return t;
	};
	_proto._Wait40_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set43_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object43_i();
		return t;
	};
	_proto._Object43_i = function () {
		var t = {};
		this._Object43 = t;
		return t;
	};
	_proto.enterSpec_i = function () {
		var t = new egret.tween.TweenGroup();
		this.enterSpec = t;
		t.items = [this._TweenItem9_i(),this._TweenItem10_i()];
		return t;
	};
	_proto._TweenItem9_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem9 = t;
		t.paths = [this._Wait41_i(),this._Set44_i(),this._Wait42_i(),this._Set45_i(),this._Wait43_i(),this._Set46_i(),this._Wait44_i(),this._Set47_i(),this._Wait45_i(),this._Set48_i()];
		return t;
	};
	_proto._Wait41_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set44_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object44_i();
		return t;
	};
	_proto._Object44_i = function () {
		var t = {};
		this._Object44 = t;
		return t;
	};
	_proto._Wait42_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set45_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object45_i();
		return t;
	};
	_proto._Object45_i = function () {
		var t = {};
		this._Object45 = t;
		return t;
	};
	_proto._Wait43_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set46_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object46_i();
		return t;
	};
	_proto._Object46_i = function () {
		var t = {};
		this._Object46 = t;
		return t;
	};
	_proto._Wait44_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set47_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object47_i();
		return t;
	};
	_proto._Object47_i = function () {
		var t = {};
		this._Object47 = t;
		return t;
	};
	_proto._Wait45_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set48_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object48_i();
		return t;
	};
	_proto._Object48_i = function () {
		var t = {};
		this._Object48 = t;
		return t;
	};
	_proto._TweenItem10_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem10 = t;
		t.paths = [this._Set49_i(),this._Wait46_i(),this._Set50_i(),this._Wait47_i(),this._Set51_i(),this._Wait48_i(),this._Set52_i(),this._Wait49_i(),this._Set53_i(),this._Wait50_i(),this._Set54_i()];
		return t;
	};
	_proto._Set49_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object49_i();
		return t;
	};
	_proto._Object49_i = function () {
		var t = {};
		this._Object49 = t;
		return t;
	};
	_proto._Wait46_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set50_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object50_i();
		return t;
	};
	_proto._Object50_i = function () {
		var t = {};
		this._Object50 = t;
		return t;
	};
	_proto._Wait47_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set51_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object51_i();
		return t;
	};
	_proto._Object51_i = function () {
		var t = {};
		this._Object51 = t;
		return t;
	};
	_proto._Wait48_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set52_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object52_i();
		return t;
	};
	_proto._Object52_i = function () {
		var t = {};
		this._Object52 = t;
		return t;
	};
	_proto._Wait49_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set53_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object53_i();
		return t;
	};
	_proto._Object53_i = function () {
		var t = {};
		this._Object53 = t;
		return t;
	};
	_proto._Wait50_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set54_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object54_i();
		return t;
	};
	_proto._Object54_i = function () {
		var t = {};
		this._Object54 = t;
		return t;
	};
	_proto.quitSpec_i = function () {
		var t = new egret.tween.TweenGroup();
		this.quitSpec = t;
		t.items = [this._TweenItem11_i(),this._TweenItem12_i()];
		return t;
	};
	_proto._TweenItem11_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem11 = t;
		t.paths = [this._Wait51_i(),this._Set55_i(),this._Wait52_i(),this._Set56_i(),this._Wait53_i(),this._Set57_i(),this._Wait54_i(),this._Set58_i(),this._Wait55_i(),this._Set59_i()];
		return t;
	};
	_proto._Wait51_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set55_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object55_i();
		return t;
	};
	_proto._Object55_i = function () {
		var t = {};
		this._Object55 = t;
		return t;
	};
	_proto._Wait52_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set56_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object56_i();
		return t;
	};
	_proto._Object56_i = function () {
		var t = {};
		this._Object56 = t;
		return t;
	};
	_proto._Wait53_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set57_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object57_i();
		return t;
	};
	_proto._Object57_i = function () {
		var t = {};
		this._Object57 = t;
		return t;
	};
	_proto._Wait54_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set58_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object58_i();
		return t;
	};
	_proto._Object58_i = function () {
		var t = {};
		this._Object58 = t;
		return t;
	};
	_proto._Wait55_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set59_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object59_i();
		return t;
	};
	_proto._Object59_i = function () {
		var t = {};
		this._Object59 = t;
		return t;
	};
	_proto._TweenItem12_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem12 = t;
		t.paths = [this._Set60_i(),this._Wait56_i(),this._Set61_i(),this._Wait57_i(),this._Set62_i(),this._Wait58_i(),this._Set63_i(),this._Wait59_i(),this._Set64_i(),this._Wait60_i(),this._Set65_i()];
		return t;
	};
	_proto._Set60_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object60_i();
		return t;
	};
	_proto._Object60_i = function () {
		var t = {};
		this._Object60 = t;
		return t;
	};
	_proto._Wait56_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set61_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object61_i();
		return t;
	};
	_proto._Object61_i = function () {
		var t = {};
		this._Object61 = t;
		return t;
	};
	_proto._Wait57_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set62_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object62_i();
		return t;
	};
	_proto._Object62_i = function () {
		var t = {};
		this._Object62 = t;
		return t;
	};
	_proto._Wait58_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set63_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object63_i();
		return t;
	};
	_proto._Object63_i = function () {
		var t = {};
		this._Object63 = t;
		return t;
	};
	_proto._Wait59_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set64_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object64_i();
		return t;
	};
	_proto._Object64_i = function () {
		var t = {};
		this._Object64 = t;
		return t;
	};
	_proto._Wait60_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set65_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object65_i();
		return t;
	};
	_proto._Object65_i = function () {
		var t = {};
		this._Object65 = t;
		return t;
	};
	_proto.enterNewgame_i = function () {
		var t = new egret.tween.TweenGroup();
		this.enterNewgame = t;
		t.items = [this._TweenItem13_i(),this._TweenItem14_i()];
		return t;
	};
	_proto._TweenItem13_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem13 = t;
		t.paths = [this._Wait61_i(),this._Set66_i(),this._Wait62_i(),this._Set67_i(),this._Wait63_i(),this._Set68_i(),this._Wait64_i(),this._Set69_i(),this._Wait65_i(),this._Set70_i()];
		return t;
	};
	_proto._Wait61_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set66_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object66_i();
		return t;
	};
	_proto._Object66_i = function () {
		var t = {};
		this._Object66 = t;
		return t;
	};
	_proto._Wait62_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set67_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object67_i();
		return t;
	};
	_proto._Object67_i = function () {
		var t = {};
		this._Object67 = t;
		return t;
	};
	_proto._Wait63_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set68_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object68_i();
		return t;
	};
	_proto._Object68_i = function () {
		var t = {};
		this._Object68 = t;
		return t;
	};
	_proto._Wait64_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set69_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object69_i();
		return t;
	};
	_proto._Object69_i = function () {
		var t = {};
		this._Object69 = t;
		return t;
	};
	_proto._Wait65_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set70_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object70_i();
		return t;
	};
	_proto._Object70_i = function () {
		var t = {};
		this._Object70 = t;
		return t;
	};
	_proto._TweenItem14_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem14 = t;
		t.paths = [this._Set71_i(),this._Wait66_i(),this._Set72_i(),this._Wait67_i(),this._Set73_i(),this._Wait68_i(),this._Set74_i(),this._Wait69_i(),this._Set75_i(),this._Wait70_i(),this._Set76_i()];
		return t;
	};
	_proto._Set71_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object71_i();
		return t;
	};
	_proto._Object71_i = function () {
		var t = {};
		this._Object71 = t;
		return t;
	};
	_proto._Wait66_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set72_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object72_i();
		return t;
	};
	_proto._Object72_i = function () {
		var t = {};
		this._Object72 = t;
		return t;
	};
	_proto._Wait67_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set73_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object73_i();
		return t;
	};
	_proto._Object73_i = function () {
		var t = {};
		this._Object73 = t;
		return t;
	};
	_proto._Wait68_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set74_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object74_i();
		return t;
	};
	_proto._Object74_i = function () {
		var t = {};
		this._Object74 = t;
		return t;
	};
	_proto._Wait69_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set75_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object75_i();
		return t;
	};
	_proto._Object75_i = function () {
		var t = {};
		this._Object75 = t;
		return t;
	};
	_proto._Wait70_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set76_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object76_i();
		return t;
	};
	_proto._Object76_i = function () {
		var t = {};
		this._Object76 = t;
		return t;
	};
	_proto.quitNewgame_i = function () {
		var t = new egret.tween.TweenGroup();
		this.quitNewgame = t;
		t.items = [this._TweenItem15_i(),this._TweenItem16_i()];
		return t;
	};
	_proto._TweenItem15_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem15 = t;
		t.paths = [this._Wait71_i(),this._Set77_i(),this._Wait72_i(),this._Set78_i(),this._Wait73_i(),this._Set79_i(),this._Wait74_i(),this._Set80_i(),this._Wait75_i(),this._Set81_i()];
		return t;
	};
	_proto._Wait71_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set77_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object77_i();
		return t;
	};
	_proto._Object77_i = function () {
		var t = {};
		this._Object77 = t;
		return t;
	};
	_proto._Wait72_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set78_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object78_i();
		return t;
	};
	_proto._Object78_i = function () {
		var t = {};
		this._Object78 = t;
		return t;
	};
	_proto._Wait73_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set79_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object79_i();
		return t;
	};
	_proto._Object79_i = function () {
		var t = {};
		this._Object79 = t;
		return t;
	};
	_proto._Wait74_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set80_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object80_i();
		return t;
	};
	_proto._Object80_i = function () {
		var t = {};
		this._Object80 = t;
		return t;
	};
	_proto._Wait75_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set81_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object81_i();
		return t;
	};
	_proto._Object81_i = function () {
		var t = {};
		this._Object81 = t;
		return t;
	};
	_proto._TweenItem16_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem16 = t;
		t.paths = [this._Wait76_i(),this._Set82_i(),this._Wait77_i(),this._Set83_i(),this._Wait78_i(),this._Set84_i(),this._Wait79_i(),this._Set85_i(),this._Wait80_i(),this._Set86_i()];
		return t;
	};
	_proto._Wait76_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set82_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object82_i();
		return t;
	};
	_proto._Object82_i = function () {
		var t = {};
		this._Object82 = t;
		return t;
	};
	_proto._Wait77_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set83_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object83_i();
		return t;
	};
	_proto._Object83_i = function () {
		var t = {};
		this._Object83 = t;
		return t;
	};
	_proto._Wait78_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set84_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object84_i();
		return t;
	};
	_proto._Object84_i = function () {
		var t = {};
		this._Object84 = t;
		return t;
	};
	_proto._Wait79_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set85_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object85_i();
		return t;
	};
	_proto._Object85_i = function () {
		var t = {};
		this._Object85 = t;
		return t;
	};
	_proto._Wait80_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set86_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object86_i();
		return t;
	};
	_proto._Object86_i = function () {
		var t = {};
		this._Object86 = t;
		return t;
	};
	_proto.enterCreator_i = function () {
		var t = new egret.tween.TweenGroup();
		this.enterCreator = t;
		t.items = [this._TweenItem17_i(),this._TweenItem18_i()];
		return t;
	};
	_proto._TweenItem17_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem17 = t;
		t.paths = [this._Set87_i(),this._Wait81_i(),this._Set88_i(),this._Wait82_i(),this._Set89_i(),this._Wait83_i(),this._Set90_i(),this._Wait84_i(),this._Set91_i(),this._Wait85_i(),this._Set92_i()];
		return t;
	};
	_proto._Set87_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object87_i();
		return t;
	};
	_proto._Object87_i = function () {
		var t = {};
		this._Object87 = t;
		return t;
	};
	_proto._Wait81_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set88_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object88_i();
		return t;
	};
	_proto._Object88_i = function () {
		var t = {};
		this._Object88 = t;
		return t;
	};
	_proto._Wait82_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set89_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object89_i();
		return t;
	};
	_proto._Object89_i = function () {
		var t = {};
		this._Object89 = t;
		return t;
	};
	_proto._Wait83_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set90_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object90_i();
		return t;
	};
	_proto._Object90_i = function () {
		var t = {};
		this._Object90 = t;
		return t;
	};
	_proto._Wait84_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set91_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object91_i();
		return t;
	};
	_proto._Object91_i = function () {
		var t = {};
		this._Object91 = t;
		return t;
	};
	_proto._Wait85_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set92_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object92_i();
		return t;
	};
	_proto._Object92_i = function () {
		var t = {};
		this._Object92 = t;
		return t;
	};
	_proto._TweenItem18_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem18 = t;
		t.paths = [this._Set93_i(),this._Wait86_i(),this._Set94_i(),this._Wait87_i(),this._Set95_i(),this._Wait88_i(),this._Set96_i(),this._Wait89_i(),this._Set97_i(),this._Wait90_i(),this._Set98_i()];
		return t;
	};
	_proto._Set93_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object93_i();
		return t;
	};
	_proto._Object93_i = function () {
		var t = {};
		this._Object93 = t;
		return t;
	};
	_proto._Wait86_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set94_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object94_i();
		return t;
	};
	_proto._Object94_i = function () {
		var t = {};
		this._Object94 = t;
		return t;
	};
	_proto._Wait87_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set95_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object95_i();
		return t;
	};
	_proto._Object95_i = function () {
		var t = {};
		this._Object95 = t;
		return t;
	};
	_proto._Wait88_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set96_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object96_i();
		return t;
	};
	_proto._Object96_i = function () {
		var t = {};
		this._Object96 = t;
		return t;
	};
	_proto._Wait89_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set97_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object97_i();
		return t;
	};
	_proto._Object97_i = function () {
		var t = {};
		this._Object97 = t;
		return t;
	};
	_proto._Wait90_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set98_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object98_i();
		return t;
	};
	_proto._Object98_i = function () {
		var t = {};
		this._Object98 = t;
		return t;
	};
	_proto.quitCreator_i = function () {
		var t = new egret.tween.TweenGroup();
		this.quitCreator = t;
		t.items = [this._TweenItem19_i(),this._TweenItem20_i()];
		return t;
	};
	_proto._TweenItem19_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem19 = t;
		t.paths = [this._Wait91_i(),this._Set99_i(),this._Wait92_i(),this._Set100_i(),this._Wait93_i(),this._Set101_i(),this._Wait94_i(),this._Set102_i(),this._Wait95_i(),this._Set103_i()];
		return t;
	};
	_proto._Wait91_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set99_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object99_i();
		return t;
	};
	_proto._Object99_i = function () {
		var t = {};
		this._Object99 = t;
		return t;
	};
	_proto._Wait92_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set100_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object100_i();
		return t;
	};
	_proto._Object100_i = function () {
		var t = {};
		this._Object100 = t;
		return t;
	};
	_proto._Wait93_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set101_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object101_i();
		return t;
	};
	_proto._Object101_i = function () {
		var t = {};
		this._Object101 = t;
		return t;
	};
	_proto._Wait94_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set102_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object102_i();
		return t;
	};
	_proto._Object102_i = function () {
		var t = {};
		this._Object102 = t;
		return t;
	};
	_proto._Wait95_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set103_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object103_i();
		return t;
	};
	_proto._Object103_i = function () {
		var t = {};
		this._Object103 = t;
		return t;
	};
	_proto._TweenItem20_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem20 = t;
		t.paths = [this._Set104_i(),this._Wait96_i(),this._Set105_i(),this._Wait97_i(),this._Set106_i(),this._Wait98_i(),this._Set107_i(),this._Wait99_i(),this._Set108_i(),this._Wait100_i(),this._Set109_i()];
		return t;
	};
	_proto._Set104_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object104_i();
		return t;
	};
	_proto._Object104_i = function () {
		var t = {};
		this._Object104 = t;
		return t;
	};
	_proto._Wait96_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set105_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object105_i();
		return t;
	};
	_proto._Object105_i = function () {
		var t = {};
		this._Object105 = t;
		return t;
	};
	_proto._Wait97_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set106_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object106_i();
		return t;
	};
	_proto._Object106_i = function () {
		var t = {};
		this._Object106 = t;
		return t;
	};
	_proto._Wait98_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set107_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object107_i();
		return t;
	};
	_proto._Object107_i = function () {
		var t = {};
		this._Object107 = t;
		return t;
	};
	_proto._Wait99_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set108_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object108_i();
		return t;
	};
	_proto._Object108_i = function () {
		var t = {};
		this._Object108 = t;
		return t;
	};
	_proto._Wait100_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set109_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object109_i();
		return t;
	};
	_proto._Object109_i = function () {
		var t = {};
		this._Object109 = t;
		return t;
	};
	_proto.enterCollec_i = function () {
		var t = new egret.tween.TweenGroup();
		this.enterCollec = t;
		t.items = [this._TweenItem21_i(),this._TweenItem22_i()];
		return t;
	};
	_proto._TweenItem21_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem21 = t;
		t.paths = [this._Wait101_i(),this._Set110_i(),this._Wait102_i(),this._Set111_i(),this._Wait103_i(),this._Set112_i(),this._Wait104_i(),this._Set113_i(),this._Wait105_i(),this._Set114_i()];
		return t;
	};
	_proto._Wait101_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set110_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object110_i();
		return t;
	};
	_proto._Object110_i = function () {
		var t = {};
		this._Object110 = t;
		return t;
	};
	_proto._Wait102_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set111_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object111_i();
		return t;
	};
	_proto._Object111_i = function () {
		var t = {};
		this._Object111 = t;
		return t;
	};
	_proto._Wait103_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set112_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object112_i();
		return t;
	};
	_proto._Object112_i = function () {
		var t = {};
		this._Object112 = t;
		return t;
	};
	_proto._Wait104_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set113_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object113_i();
		return t;
	};
	_proto._Object113_i = function () {
		var t = {};
		this._Object113 = t;
		return t;
	};
	_proto._Wait105_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set114_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object114_i();
		return t;
	};
	_proto._Object114_i = function () {
		var t = {};
		this._Object114 = t;
		return t;
	};
	_proto._TweenItem22_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem22 = t;
		t.paths = [this._Set115_i(),this._Wait106_i(),this._Set116_i(),this._Wait107_i(),this._Set117_i(),this._Wait108_i(),this._Set118_i(),this._Wait109_i(),this._Set119_i(),this._Wait110_i(),this._Set120_i()];
		return t;
	};
	_proto._Set115_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object115_i();
		return t;
	};
	_proto._Object115_i = function () {
		var t = {};
		this._Object115 = t;
		return t;
	};
	_proto._Wait106_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set116_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object116_i();
		return t;
	};
	_proto._Object116_i = function () {
		var t = {};
		this._Object116 = t;
		return t;
	};
	_proto._Wait107_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set117_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object117_i();
		return t;
	};
	_proto._Object117_i = function () {
		var t = {};
		this._Object117 = t;
		return t;
	};
	_proto._Wait108_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set118_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object118_i();
		return t;
	};
	_proto._Object118_i = function () {
		var t = {};
		this._Object118 = t;
		return t;
	};
	_proto._Wait109_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set119_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object119_i();
		return t;
	};
	_proto._Object119_i = function () {
		var t = {};
		this._Object119 = t;
		return t;
	};
	_proto._Wait110_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set120_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object120_i();
		return t;
	};
	_proto._Object120_i = function () {
		var t = {};
		this._Object120 = t;
		return t;
	};
	_proto.quitCollec_i = function () {
		var t = new egret.tween.TweenGroup();
		this.quitCollec = t;
		t.items = [this._TweenItem23_i(),this._TweenItem24_i()];
		return t;
	};
	_proto._TweenItem23_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem23 = t;
		t.paths = [this._Wait111_i(),this._Set121_i(),this._Wait112_i(),this._Set122_i(),this._Wait113_i(),this._Set123_i(),this._Wait114_i(),this._Set124_i(),this._Wait115_i(),this._Set125_i()];
		return t;
	};
	_proto._Wait111_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set121_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object121_i();
		return t;
	};
	_proto._Object121_i = function () {
		var t = {};
		this._Object121 = t;
		return t;
	};
	_proto._Wait112_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set122_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object122_i();
		return t;
	};
	_proto._Object122_i = function () {
		var t = {};
		this._Object122 = t;
		return t;
	};
	_proto._Wait113_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set123_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object123_i();
		return t;
	};
	_proto._Object123_i = function () {
		var t = {};
		this._Object123 = t;
		return t;
	};
	_proto._Wait114_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set124_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object124_i();
		return t;
	};
	_proto._Object124_i = function () {
		var t = {};
		this._Object124 = t;
		return t;
	};
	_proto._Wait115_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set125_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object125_i();
		return t;
	};
	_proto._Object125_i = function () {
		var t = {};
		this._Object125 = t;
		return t;
	};
	_proto._TweenItem24_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem24 = t;
		t.paths = [this._Set126_i(),this._Wait116_i(),this._Set127_i(),this._Wait117_i(),this._Set128_i(),this._Wait118_i(),this._Set129_i(),this._Wait119_i(),this._Set130_i(),this._Wait120_i(),this._Set131_i()];
		return t;
	};
	_proto._Set126_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object126_i();
		return t;
	};
	_proto._Object126_i = function () {
		var t = {};
		this._Object126 = t;
		return t;
	};
	_proto._Wait116_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set127_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object127_i();
		return t;
	};
	_proto._Object127_i = function () {
		var t = {};
		this._Object127 = t;
		return t;
	};
	_proto._Wait117_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set128_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object128_i();
		return t;
	};
	_proto._Object128_i = function () {
		var t = {};
		this._Object128 = t;
		return t;
	};
	_proto._Wait118_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set129_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object129_i();
		return t;
	};
	_proto._Object129_i = function () {
		var t = {};
		this._Object129 = t;
		return t;
	};
	_proto._Wait119_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set130_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object130_i();
		return t;
	};
	_proto._Object130_i = function () {
		var t = {};
		this._Object130 = t;
		return t;
	};
	_proto._Wait120_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set131_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object131_i();
		return t;
	};
	_proto._Object131_i = function () {
		var t = {};
		this._Object131 = t;
		return t;
	};
	_proto.enterQuitgame_i = function () {
		var t = new egret.tween.TweenGroup();
		this.enterQuitgame = t;
		t.items = [this._TweenItem25_i(),this._TweenItem26_i()];
		return t;
	};
	_proto._TweenItem25_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem25 = t;
		t.paths = [this._Wait121_i(),this._Set132_i(),this._Wait122_i(),this._Set133_i(),this._Wait123_i(),this._Set134_i(),this._Wait124_i(),this._Set135_i(),this._Wait125_i(),this._Set136_i()];
		return t;
	};
	_proto._Wait121_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set132_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object132_i();
		return t;
	};
	_proto._Object132_i = function () {
		var t = {};
		this._Object132 = t;
		return t;
	};
	_proto._Wait122_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set133_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object133_i();
		return t;
	};
	_proto._Object133_i = function () {
		var t = {};
		this._Object133 = t;
		return t;
	};
	_proto._Wait123_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set134_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object134_i();
		return t;
	};
	_proto._Object134_i = function () {
		var t = {};
		this._Object134 = t;
		return t;
	};
	_proto._Wait124_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set135_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object135_i();
		return t;
	};
	_proto._Object135_i = function () {
		var t = {};
		this._Object135 = t;
		return t;
	};
	_proto._Wait125_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set136_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object136_i();
		return t;
	};
	_proto._Object136_i = function () {
		var t = {};
		this._Object136 = t;
		return t;
	};
	_proto._TweenItem26_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem26 = t;
		t.paths = [this._Set137_i(),this._Wait126_i(),this._Set138_i(),this._Wait127_i(),this._Set139_i(),this._Wait128_i(),this._Set140_i(),this._Wait129_i(),this._Set141_i(),this._Wait130_i(),this._Set142_i()];
		return t;
	};
	_proto._Set137_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object137_i();
		return t;
	};
	_proto._Object137_i = function () {
		var t = {};
		this._Object137 = t;
		return t;
	};
	_proto._Wait126_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set138_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object138_i();
		return t;
	};
	_proto._Object138_i = function () {
		var t = {};
		this._Object138 = t;
		return t;
	};
	_proto._Wait127_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set139_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object139_i();
		return t;
	};
	_proto._Object139_i = function () {
		var t = {};
		this._Object139 = t;
		return t;
	};
	_proto._Wait128_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set140_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object140_i();
		return t;
	};
	_proto._Object140_i = function () {
		var t = {};
		this._Object140 = t;
		return t;
	};
	_proto._Wait129_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set141_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object141_i();
		return t;
	};
	_proto._Object141_i = function () {
		var t = {};
		this._Object141 = t;
		return t;
	};
	_proto._Wait130_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set142_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object142_i();
		return t;
	};
	_proto._Object142_i = function () {
		var t = {};
		this._Object142 = t;
		return t;
	};
	_proto.quiQuitgame_i = function () {
		var t = new egret.tween.TweenGroup();
		this.quiQuitgame = t;
		t.items = [this._TweenItem27_i(),this._TweenItem28_i()];
		return t;
	};
	_proto._TweenItem27_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem27 = t;
		t.paths = [this._Wait131_i(),this._Set143_i(),this._Wait132_i(),this._Set144_i(),this._Wait133_i(),this._Set145_i(),this._Wait134_i(),this._Set146_i(),this._Wait135_i(),this._Set147_i()];
		return t;
	};
	_proto._Wait131_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set143_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object143_i();
		return t;
	};
	_proto._Object143_i = function () {
		var t = {};
		this._Object143 = t;
		return t;
	};
	_proto._Wait132_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set144_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object144_i();
		return t;
	};
	_proto._Object144_i = function () {
		var t = {};
		this._Object144 = t;
		return t;
	};
	_proto._Wait133_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set145_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object145_i();
		return t;
	};
	_proto._Object145_i = function () {
		var t = {};
		this._Object145 = t;
		return t;
	};
	_proto._Wait134_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set146_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object146_i();
		return t;
	};
	_proto._Object146_i = function () {
		var t = {};
		this._Object146 = t;
		return t;
	};
	_proto._Wait135_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set147_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object147_i();
		return t;
	};
	_proto._Object147_i = function () {
		var t = {};
		this._Object147 = t;
		return t;
	};
	_proto._TweenItem28_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem28 = t;
		t.paths = [this._Set148_i(),this._Wait136_i(),this._Set149_i(),this._Wait137_i(),this._Set150_i(),this._Wait138_i(),this._Set151_i(),this._Wait139_i(),this._Set152_i(),this._Wait140_i(),this._Set153_i()];
		return t;
	};
	_proto._Set148_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object148_i();
		return t;
	};
	_proto._Object148_i = function () {
		var t = {};
		this._Object148 = t;
		return t;
	};
	_proto._Wait136_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set149_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object149_i();
		return t;
	};
	_proto._Object149_i = function () {
		var t = {};
		this._Object149 = t;
		return t;
	};
	_proto._Wait137_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set150_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object150_i();
		return t;
	};
	_proto._Object150_i = function () {
		var t = {};
		this._Object150 = t;
		return t;
	};
	_proto._Wait138_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set151_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object151_i();
		return t;
	};
	_proto._Object151_i = function () {
		var t = {};
		this._Object151 = t;
		return t;
	};
	_proto._Wait139_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set152_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object152_i();
		return t;
	};
	_proto._Object152_i = function () {
		var t = {};
		this._Object152 = t;
		return t;
	};
	_proto._Wait140_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set153_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object153_i();
		return t;
	};
	_proto._Object153_i = function () {
		var t = {};
		this._Object153 = t;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 1080;
		t.source = "mainbackdrop_png";
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.main_stack_i = function () {
		var t = new eui.Group();
		this.main_stack = t;
		t.height = 827;
		t.width = 800;
		t.x = 1040;
		t.y = 127;
		t.elementsContent = [this.setting_enter_i(),this.start_enter_i(),this.main_layout_i(),this.spec_enter_i(),this.collection_enter_i(),this.quit_enter_i(),this.newgame_enter_i(),this.creator_enter_i()];
		return t;
	};
	_proto.setting_enter_i = function () {
		var t = new eui.Group();
		this.setting_enter = t;
		t.height = 827;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image2_i(),this.music_i(),this.voice_like_i(),this.spec_return_i(),this.specification_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 787.82;
		t.source = "setting_ui_png";
		t.width = 626;
		t.x = 66;
		t.y = 9.18;
		return t;
	};
	_proto.music_i = function () {
		var t = new eui.CheckBox();
		this.music = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 67;
		t.label = "";
		t.width = 47;
		t.x = 461;
		t.y = 512.5;
		return t;
	};
	_proto.voice_like_i = function () {
		var t = new eui.CheckBox();
		this.voice_like = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 53;
		t.label = "";
		t.width = 71;
		t.x = 463;
		t.y = 645.64;
		return t;
	};
	_proto.spec_return_i = function () {
		var t = new eui.Button();
		this.spec_return = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 120;
		t.label = "";
		t.width = 190;
		t.x = 680;
		t.y = 0;
		t.skinName = main_interfaceSkin$Skin1;
		return t;
	};
	_proto.specification_i = function () {
		var t = new eui.Button();
		this.specification = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 116.36;
		t.label = "";
		t.width = 365.51;
		t.x = 172.73;
		t.y = 253.5;
		t.skinName = main_interfaceSkin$Skin2;
		return t;
	};
	_proto.start_enter_i = function () {
		var t = new eui.Group();
		this.start_enter = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 827;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.new_game_i(),this.start_return_i(),this.memo1_i(),this.memo2_i(),this.memo3_i(),this._Image6_i()];
		return t;
	};
	_proto.new_game_i = function () {
		var t = new eui.Button();
		this.new_game = t;
		t.anchorOffsetY = 0;
		t.height = 100;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 500;
		t.x = 150;
		t.y = 142;
		t.skinName = main_interfaceSkin$Skin3;
		return t;
	};
	_proto.start_return_i = function () {
		var t = new eui.Button();
		this.start_return = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 120;
		t.label = "";
		t.width = 190;
		t.x = 680;
		t.y = 0;
		t.skinName = main_interfaceSkin$Skin4;
		return t;
	};
	_proto.memo1_i = function () {
		var t = new eui.Group();
		this.memo1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 108;
		t.width = 500;
		t.x = 150;
		t.y = 309;
		t.elementsContent = [this._Image3_i(),this.memo1_text_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.height = 108;
		t.source = "savegame_png";
		t.width = 500;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.memo1_text_i = function () {
		var t = new eui.Label();
		this.memo1_text = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 70;
		t.size = 50;
		t.text = "";
		t.textColor = 0x000000;
		t.width = 220;
		t.x = 167;
		t.y = 23;
		return t;
	};
	_proto.memo2_i = function () {
		var t = new eui.Group();
		this.memo2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 108;
		t.width = 500;
		t.x = 151;
		t.y = 462.5;
		t.elementsContent = [this._Image4_i(),this.memo2_text_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.height = 108;
		t.source = "savegame_png";
		t.width = 500;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.memo2_text_i = function () {
		var t = new eui.Label();
		this.memo2_text = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 65;
		t.size = 50;
		t.text = "";
		t.textColor = 0x000000;
		t.width = 220;
		t.x = 166;
		t.y = 27.5;
		return t;
	};
	_proto.memo3_i = function () {
		var t = new eui.Group();
		this.memo3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 108;
		t.width = 500;
		t.x = 151;
		t.y = 632;
		t.elementsContent = [this._Image5_i(),this.memo3_text_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.height = 108;
		t.source = "savegame_png";
		t.width = 500;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.memo3_text_i = function () {
		var t = new eui.Label();
		this.memo3_text = t;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 65;
		t.size = 50;
		t.text = "";
		t.textColor = 0x000000;
		t.width = 220;
		t.x = 169;
		t.y = 25;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.height = 827;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.main_layout_i = function () {
		var t = new eui.Group();
		this.main_layout = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 827;
		t.name = "Group";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.start_game_i(),this.setting_i(),this.collection_i(),this.quit_i(),this.creator_i()];
		return t;
	};
	_proto.start_game_i = function () {
		var t = new eui.Button();
		this.start_game = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 98.18;
		t.label = "";
		t.width = 500;
		t.x = 150;
		t.y = 71;
		t.skinName = main_interfaceSkin$Skin5;
		return t;
	};
	_proto.setting_i = function () {
		var t = new eui.Button();
		this.setting = t;
		t.anchorOffsetY = 0;
		t.height = 106.91;
		t.label = "";
		t.width = 500;
		t.x = 150;
		t.y = 217.5;
		t.skinName = main_interfaceSkin$Skin6;
		return t;
	};
	_proto.collection_i = function () {
		var t = new eui.Button();
		this.collection = t;
		t.anchorOffsetY = 0;
		t.height = 104;
		t.label = "";
		t.width = 500;
		t.x = 150;
		t.y = 546;
		t.skinName = main_interfaceSkin$Skin7;
		return t;
	};
	_proto.quit_i = function () {
		var t = new eui.Button();
		this.quit = t;
		t.anchorOffsetY = 0;
		t.height = 106;
		t.label = "";
		t.width = 500;
		t.x = 150;
		t.y = 689;
		t.skinName = main_interfaceSkin$Skin8;
		return t;
	};
	_proto.creator_i = function () {
		var t = new eui.Button();
		this.creator = t;
		t.anchorOffsetY = 0;
		t.height = 104;
		t.label = "";
		t.width = 500;
		t.x = 150;
		t.y = 379;
		t.skinName = main_interfaceSkin$Skin9;
		return t;
	};
	_proto.spec_enter_i = function () {
		var t = new eui.Group();
		this.spec_enter = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 827;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image7_i(),this._Label1_i(),this._Label2_i(),this.spec_detail_return_i()];
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 917.69;
		t.source = "caozuo_detail_png";
		t.width = 787.51;
		t.x = 9.58;
		t.y = 1.52;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 583.04;
		t.text = "作为混乱之主的手下，你奉命扮演虚假的爱神制造虚假的“好男人”愚弄人类在人间传递混乱。 每一天点击门开始今天的营业，在规定时间内尽量帮助更多女孩获得她们的“梦中情男”吧～ 单击对应药剂即可把药拿在手上，长按即可往锅里倒入对应药剂，松开鼠标即可停止倒药（会有回摇动作哦owo） 查看不同药剂对应标签可以在游戏里（图）处查看～ 已完成的愿望及其详情都可以在（图）处查看～ 每笔订单完成后便会进行渣值PK随后产生混乱值的奖惩，一天结束后混乱值将决定你是否能保住目前这份工作。 加油吧！小喽啰！";
		t.textColor = 0x020000;
		t.width = 472.49;
		t.x = 154.03;
		t.y = 186.3;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 60.3;
		t.text = "操作说明";
		t.textColor = 0x000000;
		t.width = 234.61;
		t.x = 287;
		t.y = 53;
		return t;
	};
	_proto.spec_detail_return_i = function () {
		var t = new eui.Button();
		this.spec_detail_return = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 120;
		t.label = "";
		t.width = 190;
		t.x = 680;
		t.y = 0;
		t.skinName = main_interfaceSkin$Skin10;
		return t;
	};
	_proto.collection_enter_i = function () {
		var t = new eui.Group();
		this.collection_enter = t;
		t.height = 827;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image8_i(),this.collection_return_i()];
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 827;
		t.source = "collection_bg_png";
		t.width = 800;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.collection_return_i = function () {
		var t = new eui.Button();
		this.collection_return = t;
		t.anchorOffsetX = 0;
		t.height = 120;
		t.label = "";
		t.width = 190;
		t.x = 680;
		t.y = 0;
		t.skinName = main_interfaceSkin$Skin11;
		return t;
	};
	_proto.quit_enter_i = function () {
		var t = new eui.Group();
		this.quit_enter = t;
		t.height = 827;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image9_i(),this.sure_quit_i(),this.quit_return_i()];
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 514.42;
		t.source = "quitClue_png";
		t.width = 671.39;
		t.x = 74.27;
		t.y = 199.08;
		return t;
	};
	_proto.sure_quit_i = function () {
		var t = new eui.Button();
		this.sure_quit = t;
		t.height = 100;
		t.label = "";
		t.width = 200;
		t.x = 300;
		t.y = 526;
		t.skinName = main_interfaceSkin$Skin12;
		return t;
	};
	_proto.quit_return_i = function () {
		var t = new eui.Button();
		this.quit_return = t;
		t.anchorOffsetY = 0;
		t.height = 120;
		t.label = "";
		t.width = 190;
		t.x = 680;
		t.y = 0;
		t.skinName = main_interfaceSkin$Skin13;
		return t;
	};
	_proto.newgame_enter_i = function () {
		var t = new eui.Group();
		this.newgame_enter = t;
		t.height = 827;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image10_i(),this.usr_name_i(),this.name_queding_i(),this.name_cancel_i(),this.illegal_i()];
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 624.67;
		t.source = "inputClue_png";
		t.width = 787.99;
		t.x = 10.61;
		t.y = 20.97;
		return t;
	};
	_proto.usr_name_i = function () {
		var t = new eui.TextInput();
		this.usr_name = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 80;
		t.width = 500;
		t.x = 190;
		t.y = 323;
		return t;
	};
	_proto.name_queding_i = function () {
		var t = new eui.Button();
		this.name_queding = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 104.24;
		t.label = "";
		t.width = 200;
		t.x = 322;
		t.y = 497.88;
		t.skinName = main_interfaceSkin$Skin14;
		return t;
	};
	_proto.name_cancel_i = function () {
		var t = new eui.Button();
		this.name_cancel = t;
		t.height = 120;
		t.label = "";
		t.width = 190;
		t.x = 680;
		t.y = 0;
		t.skinName = main_interfaceSkin$Skin15;
		return t;
	};
	_proto.illegal_i = function () {
		var t = new eui.Label();
		this.illegal = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 62;
		t.text = "用户名不能为空或特殊符号";
		t.textColor = 0x000000;
		t.width = 384;
		t.x = 287;
		t.y = 425.29;
		return t;
	};
	_proto.creator_enter_i = function () {
		var t = new eui.Group();
		this.creator_enter = t;
		t.height = 827;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 800;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image11_i(),this.creator_return_i()];
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 827;
		t.source = "creator_bg_png";
		t.width = 800;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.creator_return_i = function () {
		var t = new eui.Button();
		this.creator_return = t;
		t.height = 120;
		t.label = "";
		t.width = 190;
		t.x = 680;
		t.y = 0;
		t.skinName = main_interfaceSkin$Skin16;
		return t;
	};
	_proto.end_i = function () {
		var t = new eui.Image();
		this.end = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1080;
		t.source = "end_png";
		t.visible = false;
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		return t;
	};
	return main_interfaceSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin_1.exml'] = window.skins.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.minHeight = 18;
		this.minWidth = 30;
		this.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "yao_jindutiao_kong_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.percentHeight = 90;
		t.source = "yao_jindutiao_man_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Tahoma";
		t.height = 7.17;
		t.horizontalCenter = 0.5;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 6.67;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin_2.exml'] = window.ProgressBarSkin_2 = (function (_super) {
	__extends(ProgressBarSkin_2, _super);
	function ProgressBarSkin_2() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.height = 300;
		this.width = 400;
		this.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
	}
	var _proto = ProgressBarSkin_2.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "jindutiao_kong_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.percentHeight = 100;
		t.source = "jindutiao_man_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "Tahoma";
		t.height = 7.17;
		t.horizontalCenter = 0.5;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.width = 6.67;
		return t;
	};
	return ProgressBarSkin_2;
})(eui.Skin);generateEUI.paths['resource/eui_skins/menu_new.exml'] = window.menuSkin = (function (_super) {
	__extends(menuSkin, _super);
	var menuSkin$Skin17 = 	(function (_super) {
		__extends(menuSkin$Skin17, _super);
		function menuSkin$Skin17() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin17.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "close_door_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin17;
	})(eui.Skin);

	var menuSkin$Skin18 = 	(function (_super) {
		__extends(menuSkin$Skin18, _super);
		function menuSkin$Skin18() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin18.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "setting_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin18;
	})(eui.Skin);

	var menuSkin$Skin19 = 	(function (_super) {
		__extends(menuSkin$Skin19, _super);
		function menuSkin$Skin19() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin19.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "show_buyer_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin19;
	})(eui.Skin);

	var menuSkin$Skin20 = 	(function (_super) {
		__extends(menuSkin$Skin20, _super);
		function menuSkin$Skin20() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin20.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "compare_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin20;
	})(eui.Skin);

	var menuSkin$Skin21 = 	(function (_super) {
		__extends(menuSkin$Skin21, _super);
		function menuSkin$Skin21() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin21.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "shi_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin21;
	})(eui.Skin);

	var menuSkin$Skin22 = 	(function (_super) {
		__extends(menuSkin$Skin22, _super);
		function menuSkin$Skin22() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin22.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "fou_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin22;
	})(eui.Skin);

	var menuSkin$Skin23 = 	(function (_super) {
		__extends(menuSkin$Skin23, _super);
		function menuSkin$Skin23() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin23.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "cha_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin23;
	})(eui.Skin);

	var menuSkin$Skin24 = 	(function (_super) {
		__extends(menuSkin$Skin24, _super);
		function menuSkin$Skin24() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin24.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "cha_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin24;
	})(eui.Skin);

	var menuSkin$Skin25 = 	(function (_super) {
		__extends(menuSkin$Skin25, _super);
		function menuSkin$Skin25() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin25.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "reward_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin25;
	})(eui.Skin);

	function menuSkin() {
		_super.call(this);
		this.skinParts = ["fraction","bg","pipe","equip","l_guo","Clock","ghost_pic","ghost","factory","progress0","miss_Num","guo","l_door","door_btn","setting","m_num","mass","l_note","l_buyshow","buy_show","l_yes","i_img","i_imagine","imagine","cvs","l_p1","l_p2","l_p3","l_p4","l_p5","l_p6","l_p7","l_p8","l_piBgeye","l_pSkin","l_pDye","l_pcolar","p1","p2","p3","p4","p5","p6","p7","p8","p_bigeye","p_Skin","p_dye","p_colar","yaoshui","note","notice","med_btn","new_user","u1_user","u2_user","u3_user","u4_user","users","mix_bar","dialog","ask_panel","content","somebody","yes","no","communication","whole_layout","tc_label","tucao","show_0","show_1","show_2","show_3","show_4","show_5","fanhui","panel1","cha","note_panel","lead1","cover1","leader1","lead2","leader2","lead3","cover3","leader3","test","cover0","tt","finish_bg","poison","finish_l","finish_b","finish_z","finish_f","finish","lead","cover","leader","endpic"];
		
		this.height = 1080;
		this.width = 1920;
		this.fraction_i();
		this.elementsContent = [this.whole_layout_i(),this.tucao_i(),this.panel1_i(),this.note_panel_i(),this.leader1_i(),this.leader2_i(),this.leader3_i(),this.tt_i(),this.finish_i(),this.leader_i(),this.endpic_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.head"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object1,"y");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [94],[],this._Object2,"y");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [88],[],this._Object3,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [82],[],this._Object4,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [76],[],this._Object5,"y");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [70],[],this._Object6,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [64],[],this._Object7,"y");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [58],[],this._Object8,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [52],[],this._Object9,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.neck"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object11,"alpha");
		eui.Binding.$bindProperties(this, [17],[],this._Object11,"width");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, [15],[],this._Object12,"width");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object13,"alpha");
		eui.Binding.$bindProperties(this, [13],[],this._Object13,"width");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object14,"alpha");
		eui.Binding.$bindProperties(this, [11],[],this._Object14,"width");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object15,"alpha");
		eui.Binding.$bindProperties(this, [9],[],this._Object15,"width");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object16,"alpha");
		eui.Binding.$bindProperties(this, [7],[],this._Object16,"width");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object17,"alpha");
		eui.Binding.$bindProperties(this, [7],[],this._Object17,"width");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object18,"alpha");
		eui.Binding.$bindProperties(this, [5],[],this._Object18,"width");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object19,"alpha");
		eui.Binding.$bindProperties(this, [3],[],this._Object19,"width");
		eui.Binding.$bindProperties(this, [0],[],this._Object20,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.body"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object21,"alpha");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object22,"alpha");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object23,"alpha");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object24,"alpha");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object25,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object26,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.left_arm"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object27,"alpha");
		eui.Binding.$bindProperties(this, [22],[],this._Object27,"width");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object28,"alpha");
		eui.Binding.$bindProperties(this, [17],[],this._Object28,"width");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object29,"alpha");
		eui.Binding.$bindProperties(this, [12],[],this._Object29,"width");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object30,"alpha");
		eui.Binding.$bindProperties(this, [7],[],this._Object30,"width");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object31,"alpha");
		eui.Binding.$bindProperties(this, [2],[],this._Object31,"width");
		eui.Binding.$bindProperties(this, [0],[],this._Object32,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.right_arm"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object33,"alpha");
		eui.Binding.$bindProperties(this, [22],[],this._Object33,"width");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object34,"alpha");
		eui.Binding.$bindProperties(this, [17],[],this._Object34,"width");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object35,"alpha");
		eui.Binding.$bindProperties(this, [12],[],this._Object35,"width");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object36,"alpha");
		eui.Binding.$bindProperties(this, [5],[],this._Object36,"width");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object37,"alpha");
		eui.Binding.$bindProperties(this, [3],[],this._Object37,"width");
		eui.Binding.$bindProperties(this, [0],[],this._Object38,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.left_hand"],[0],this._TweenItem6,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object39,"alpha");
		eui.Binding.$bindProperties(this, [118],[],this._Object39,"x");
		eui.Binding.$bindProperties(this, [516],[],this._Object39,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object40,"alpha");
		eui.Binding.$bindProperties(this, [112],[],this._Object40,"x");
		eui.Binding.$bindProperties(this, [522],[],this._Object40,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object41,"alpha");
		eui.Binding.$bindProperties(this, [106],[],this._Object41,"x");
		eui.Binding.$bindProperties(this, [528],[],this._Object41,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object42,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object42,"x");
		eui.Binding.$bindProperties(this, [534],[],this._Object42,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object43,"alpha");
		eui.Binding.$bindProperties(this, [94],[],this._Object43,"x");
		eui.Binding.$bindProperties(this, [540],[],this._Object43,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object44,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.left_leg"],[0],this._TweenItem7,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object45,"alpha");
		eui.Binding.$bindProperties(this, [587],[],this._Object45,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object46,"alpha");
		eui.Binding.$bindProperties(this, [593],[],this._Object46,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object47,"alpha");
		eui.Binding.$bindProperties(this, [599],[],this._Object47,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object48,"alpha");
		eui.Binding.$bindProperties(this, [605],[],this._Object48,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object49,"alpha");
		eui.Binding.$bindProperties(this, [611],[],this._Object49,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object50,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.right_leg"],[0],this._TweenItem8,"target");
		eui.Binding.$bindProperties(this, [600],[],this._Object51,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object52,"alpha");
		eui.Binding.$bindProperties(this, [606],[],this._Object52,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object53,"alpha");
		eui.Binding.$bindProperties(this, [612],[],this._Object53,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object54,"alpha");
		eui.Binding.$bindProperties(this, [624],[],this._Object54,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object55,"alpha");
		eui.Binding.$bindProperties(this, [624],[],this._Object55,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object56,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.right_hand"],[0],this._TweenItem9,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object57,"alpha");
		eui.Binding.$bindProperties(this, [505],[],this._Object57,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object58,"alpha");
		eui.Binding.$bindProperties(this, [511],[],this._Object58,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object59,"alpha");
		eui.Binding.$bindProperties(this, [517],[],this._Object59,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object60,"alpha");
		eui.Binding.$bindProperties(this, [523],[],this._Object60,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object61,"alpha");
		eui.Binding.$bindProperties(this, [529],[],this._Object61,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object62,"alpha");
	}
	var _proto = menuSkin.prototype;

	_proto.fraction_i = function () {
		var t = new egret.tween.TweenGroup();
		this.fraction = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i(),this._TweenItem5_i(),this._TweenItem6_i(),this._TweenItem7_i(),this._TweenItem8_i(),this._TweenItem9_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Wait1_i(),this._Set1_i(),this._Wait2_i(),this._Set2_i(),this._Wait3_i(),this._Set3_i(),this._Wait4_i(),this._Set4_i(),this._Wait5_i(),this._Set5_i(),this._Wait6_i(),this._Set6_i(),this._Wait7_i(),this._Set7_i(),this._Wait8_i(),this._Set8_i(),this._Wait9_i(),this._Set9_i(),this._Wait10_i(),this._Set10_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait8_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._Wait9_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait10_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait11_i(),this._Set11_i(),this._Wait12_i(),this._Set12_i(),this._Wait13_i(),this._Set13_i(),this._Wait14_i(),this._Set14_i(),this._Wait15_i(),this._Set15_i(),this._Wait16_i(),this._Set16_i(),this._Wait17_i(),this._Set17_i(),this._Wait18_i(),this._Set18_i(),this._Wait19_i(),this._Set19_i(),this._Wait20_i(),this._Set20_i()];
		return t;
	};
	_proto._Wait11_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Wait12_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set12_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._Wait13_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set13_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._Wait14_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set14_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._Wait15_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set15_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto._Wait16_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set16_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto._Wait17_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set17_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._Wait18_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set18_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._Wait19_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set19_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object19_i();
		return t;
	};
	_proto._Object19_i = function () {
		var t = {};
		this._Object19 = t;
		return t;
	};
	_proto._Wait20_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set20_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object20_i();
		return t;
	};
	_proto._Object20_i = function () {
		var t = {};
		this._Object20 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Wait21_i(),this._Set21_i(),this._Wait22_i(),this._Set22_i(),this._Wait23_i(),this._Set23_i(),this._Wait24_i(),this._Set24_i(),this._Wait25_i(),this._Set25_i(),this._Wait26_i(),this._Set26_i()];
		return t;
	};
	_proto._Wait21_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set21_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object21_i();
		return t;
	};
	_proto._Object21_i = function () {
		var t = {};
		this._Object21 = t;
		return t;
	};
	_proto._Wait22_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set22_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object22_i();
		return t;
	};
	_proto._Object22_i = function () {
		var t = {};
		this._Object22 = t;
		return t;
	};
	_proto._Wait23_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set23_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object23_i();
		return t;
	};
	_proto._Object23_i = function () {
		var t = {};
		this._Object23 = t;
		return t;
	};
	_proto._Wait24_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set24_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object24_i();
		return t;
	};
	_proto._Object24_i = function () {
		var t = {};
		this._Object24 = t;
		return t;
	};
	_proto._Wait25_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set25_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object25_i();
		return t;
	};
	_proto._Object25_i = function () {
		var t = {};
		this._Object25 = t;
		return t;
	};
	_proto._Wait26_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set26_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object26_i();
		return t;
	};
	_proto._Object26_i = function () {
		var t = {};
		this._Object26 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Wait27_i(),this._Set27_i(),this._Wait28_i(),this._Set28_i(),this._Wait29_i(),this._Set29_i(),this._Wait30_i(),this._Set30_i(),this._Wait31_i(),this._Set31_i(),this._Wait32_i(),this._Set32_i()];
		return t;
	};
	_proto._Wait27_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set27_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object27_i();
		return t;
	};
	_proto._Object27_i = function () {
		var t = {};
		this._Object27 = t;
		return t;
	};
	_proto._Wait28_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set28_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object28_i();
		return t;
	};
	_proto._Object28_i = function () {
		var t = {};
		this._Object28 = t;
		return t;
	};
	_proto._Wait29_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set29_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object29_i();
		return t;
	};
	_proto._Object29_i = function () {
		var t = {};
		this._Object29 = t;
		return t;
	};
	_proto._Wait30_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set30_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object30_i();
		return t;
	};
	_proto._Object30_i = function () {
		var t = {};
		this._Object30 = t;
		return t;
	};
	_proto._Wait31_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set31_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object31_i();
		return t;
	};
	_proto._Object31_i = function () {
		var t = {};
		this._Object31 = t;
		return t;
	};
	_proto._Wait32_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set32_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object32_i();
		return t;
	};
	_proto._Object32_i = function () {
		var t = {};
		this._Object32 = t;
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Wait33_i(),this._Set33_i(),this._Wait34_i(),this._Set34_i(),this._Wait35_i(),this._Set35_i(),this._Wait36_i(),this._Set36_i(),this._Wait37_i(),this._Set37_i(),this._Wait38_i(),this._Set38_i()];
		return t;
	};
	_proto._Wait33_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set33_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object33_i();
		return t;
	};
	_proto._Object33_i = function () {
		var t = {};
		this._Object33 = t;
		return t;
	};
	_proto._Wait34_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set34_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object34_i();
		return t;
	};
	_proto._Object34_i = function () {
		var t = {};
		this._Object34 = t;
		return t;
	};
	_proto._Wait35_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set35_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object35_i();
		return t;
	};
	_proto._Object35_i = function () {
		var t = {};
		this._Object35 = t;
		return t;
	};
	_proto._Wait36_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set36_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object36_i();
		return t;
	};
	_proto._Object36_i = function () {
		var t = {};
		this._Object36 = t;
		return t;
	};
	_proto._Wait37_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set37_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object37_i();
		return t;
	};
	_proto._Object37_i = function () {
		var t = {};
		this._Object37 = t;
		return t;
	};
	_proto._Wait38_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set38_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object38_i();
		return t;
	};
	_proto._Object38_i = function () {
		var t = {};
		this._Object38 = t;
		return t;
	};
	_proto._TweenItem6_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem6 = t;
		t.paths = [this._Wait39_i(),this._Set39_i(),this._Wait40_i(),this._Set40_i(),this._Wait41_i(),this._Set41_i(),this._Wait42_i(),this._Set42_i(),this._Wait43_i(),this._Set43_i(),this._Wait44_i(),this._Set44_i()];
		return t;
	};
	_proto._Wait39_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set39_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object39_i();
		return t;
	};
	_proto._Object39_i = function () {
		var t = {};
		this._Object39 = t;
		return t;
	};
	_proto._Wait40_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set40_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object40_i();
		return t;
	};
	_proto._Object40_i = function () {
		var t = {};
		this._Object40 = t;
		return t;
	};
	_proto._Wait41_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set41_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object41_i();
		return t;
	};
	_proto._Object41_i = function () {
		var t = {};
		this._Object41 = t;
		return t;
	};
	_proto._Wait42_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set42_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object42_i();
		return t;
	};
	_proto._Object42_i = function () {
		var t = {};
		this._Object42 = t;
		return t;
	};
	_proto._Wait43_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set43_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object43_i();
		return t;
	};
	_proto._Object43_i = function () {
		var t = {};
		this._Object43 = t;
		return t;
	};
	_proto._Wait44_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set44_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object44_i();
		return t;
	};
	_proto._Object44_i = function () {
		var t = {};
		this._Object44 = t;
		return t;
	};
	_proto._TweenItem7_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem7 = t;
		t.paths = [this._Wait45_i(),this._Set45_i(),this._Wait46_i(),this._Set46_i(),this._Wait47_i(),this._Set47_i(),this._Wait48_i(),this._Set48_i(),this._Wait49_i(),this._Set49_i(),this._Wait50_i(),this._Set50_i()];
		return t;
	};
	_proto._Wait45_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set45_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object45_i();
		return t;
	};
	_proto._Object45_i = function () {
		var t = {};
		this._Object45 = t;
		return t;
	};
	_proto._Wait46_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set46_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object46_i();
		return t;
	};
	_proto._Object46_i = function () {
		var t = {};
		this._Object46 = t;
		return t;
	};
	_proto._Wait47_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set47_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object47_i();
		return t;
	};
	_proto._Object47_i = function () {
		var t = {};
		this._Object47 = t;
		return t;
	};
	_proto._Wait48_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set48_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object48_i();
		return t;
	};
	_proto._Object48_i = function () {
		var t = {};
		this._Object48 = t;
		return t;
	};
	_proto._Wait49_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set49_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object49_i();
		return t;
	};
	_proto._Object49_i = function () {
		var t = {};
		this._Object49 = t;
		return t;
	};
	_proto._Wait50_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set50_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object50_i();
		return t;
	};
	_proto._Object50_i = function () {
		var t = {};
		this._Object50 = t;
		return t;
	};
	_proto._TweenItem8_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem8 = t;
		t.paths = [this._Wait51_i(),this._Set51_i(),this._Wait52_i(),this._Set52_i(),this._Wait53_i(),this._Set53_i(),this._Wait54_i(),this._Set54_i(),this._Wait55_i(),this._Set55_i(),this._Wait56_i(),this._Set56_i()];
		return t;
	};
	_proto._Wait51_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set51_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object51_i();
		return t;
	};
	_proto._Object51_i = function () {
		var t = {};
		this._Object51 = t;
		return t;
	};
	_proto._Wait52_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set52_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object52_i();
		return t;
	};
	_proto._Object52_i = function () {
		var t = {};
		this._Object52 = t;
		return t;
	};
	_proto._Wait53_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set53_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object53_i();
		return t;
	};
	_proto._Object53_i = function () {
		var t = {};
		this._Object53 = t;
		return t;
	};
	_proto._Wait54_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set54_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object54_i();
		return t;
	};
	_proto._Object54_i = function () {
		var t = {};
		this._Object54 = t;
		return t;
	};
	_proto._Wait55_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set55_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object55_i();
		return t;
	};
	_proto._Object55_i = function () {
		var t = {};
		this._Object55 = t;
		return t;
	};
	_proto._Wait56_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set56_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object56_i();
		return t;
	};
	_proto._Object56_i = function () {
		var t = {};
		this._Object56 = t;
		return t;
	};
	_proto._TweenItem9_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem9 = t;
		t.paths = [this._Wait57_i(),this._Set57_i(),this._Wait58_i(),this._Set58_i(),this._Wait59_i(),this._Set59_i(),this._Wait60_i(),this._Set60_i(),this._Wait61_i(),this._Set61_i(),this._Wait62_i(),this._Set62_i()];
		return t;
	};
	_proto._Wait57_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set57_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object57_i();
		return t;
	};
	_proto._Object57_i = function () {
		var t = {};
		this._Object57 = t;
		return t;
	};
	_proto._Wait58_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set58_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object58_i();
		return t;
	};
	_proto._Object58_i = function () {
		var t = {};
		this._Object58 = t;
		return t;
	};
	_proto._Wait59_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set59_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object59_i();
		return t;
	};
	_proto._Object59_i = function () {
		var t = {};
		this._Object59 = t;
		return t;
	};
	_proto._Wait60_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set60_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object60_i();
		return t;
	};
	_proto._Object60_i = function () {
		var t = {};
		this._Object60 = t;
		return t;
	};
	_proto._Wait61_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set61_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object61_i();
		return t;
	};
	_proto._Object61_i = function () {
		var t = {};
		this._Object61 = t;
		return t;
	};
	_proto._Wait62_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set62_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object62_i();
		return t;
	};
	_proto._Object62_i = function () {
		var t = {};
		this._Object62 = t;
		return t;
	};
	_proto.whole_layout_i = function () {
		var t = new eui.Group();
		this.whole_layout = t;
		t.height = 1080;
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.bg_i(),this.pipe_i(),this.equip_i(),this.l_guo_i(),this._Image1_i(),this.Clock_i(),this.ghost_i(),this.guo_i(),this.l_door_i(),this._Image2_i(),this._Image3_i(),this.door_btn_i(),this.setting_i(),this.mass_i(),this.l_note_i(),this.l_buyshow_i(),this.buy_show_i(),this.l_yes_i(),this.imagine_i(),this.cvs_i(),this.yaoshui_i(),this.notice_i(),this.med_btn_i(),this.users_i(),this.mix_bar_i(),this.communication_i()];
		return t;
	};
	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1080;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "background_png";
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.pipe_i = function () {
		var t = new eui.Image();
		this.pipe = t;
		t.height = 897;
		t.source = "pipe_png";
		t.width = 1927;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.equip_i = function () {
		var t = new eui.Image();
		this.equip = t;
		t.height = 541;
		t.source = "equip_png";
		t.width = 1419;
		t.x = 23;
		t.y = 534;
		return t;
	};
	_proto.l_guo_i = function () {
		var t = new eui.Image();
		this.l_guo = t;
		t.alpha = 0;
		t.height = 403;
		t.source = "guo_l_png";
		t.width = 618;
		t.x = 334.92;
		t.y = 663.4;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 150;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "talk_inter_png";
		t.width = 1920;
		t.x = 0;
		t.y = 930;
		return t;
	};
	_proto.Clock_i = function () {
		var t = new eui.Group();
		this.Clock = t;
		t.height = 105;
		t.width = 80;
		t.x = 1427;
		t.y = 0;
		return t;
	};
	_proto.ghost_i = function () {
		var t = new eui.Group();
		this.ghost = t;
		t.height = 300;
		t.visible = false;
		t.width = 300;
		t.x = 352;
		t.y = 265;
		t.elementsContent = [this.ghost_pic_i()];
		return t;
	};
	_proto.ghost_pic_i = function () {
		var t = new eui.Image();
		this.ghost_pic = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 284;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "xiaoren_png";
		t.width = 222;
		t.x = 69;
		t.y = 0;
		return t;
	};
	_proto.guo_i = function () {
		var t = new eui.Group();
		this.guo = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 460;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 545;
		t.x = 216.5;
		t.y = 488.29;
		t.elementsContent = [this.factory_i(),this.progress0_i(),this.miss_Num_i()];
		return t;
	};
	_proto.factory_i = function () {
		var t = new eui.Image();
		this.factory = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 452;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "guo_png";
		t.width = 679;
		t.x = 84.5;
		t.y = 133.71;
		return t;
	};
	_proto.progress0_i = function () {
		var t = new eui.ProgressBar();
		this.progress0 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 60.62;
		t.maximum = 150;
		t.minimum = 0;
		t.rotation = 0.22;
		t.skinName = "skins.ProgressBarSkin";
		t.value = 0;
		t.width = 298.67;
		t.x = 253.71;
		t.y = 310.03;
		return t;
	};
	_proto.miss_Num_i = function () {
		var t = new eui.Label();
		this.miss_Num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 71.03;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "混乱值： ";
		t.textColor = 0xffefcc;
		t.visible = false;
		t.width = 208;
		t.x = -44;
		t.y = 89;
		return t;
	};
	_proto.l_door_i = function () {
		var t = new eui.Image();
		this.l_door = t;
		t.alpha = 0;
		t.height = 350;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "l_door_png";
		t.width = 258;
		t.x = 1562.82;
		t.y = 356;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 347;
		t.source = "black_door_png";
		t.width = 234;
		t.x = 1572;
		t.y = 352;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 347.73;
		t.source = "open_door_png";
		t.width = 237.06;
		t.x = 1572;
		t.y = 357.59;
		return t;
	};
	_proto.door_btn_i = function () {
		var t = new eui.Button();
		this.door_btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 347;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 234;
		t.x = 1572;
		t.y = 356.59;
		t.skinName = menuSkin$Skin17;
		return t;
	};
	_proto.setting_i = function () {
		var t = new eui.Button();
		this.setting = t;
		t.anchorOffsetX = 2.51;
		t.anchorOffsetY = 1.26;
		t.height = 68;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 68;
		t.x = 1823.33;
		t.y = 10.32;
		t.skinName = menuSkin$Skin18;
		return t;
	};
	_proto.mass_i = function () {
		var t = new eui.Group();
		this.mass = t;
		t.anchorOffsetY = 0;
		t.height = 124;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 200;
		t.x = 1530;
		t.y = 6.5;
		t.elementsContent = [this.m_num_i()];
		return t;
	};
	_proto.m_num_i = function () {
		var t = new eui.Label();
		this.m_num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 73.21;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "0";
		t.textColor = 0xffefcc;
		t.width = 173.33;
		t.x = 124.97;
		t.y = 100.53;
		return t;
	};
	_proto.l_note_i = function () {
		var t = new eui.Image();
		this.l_note = t;
		t.alpha = 0;
		t.height = 221;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "l_notes_png";
		t.width = 261;
		t.x = 462.99;
		t.y = 262.26;
		return t;
	};
	_proto.l_buyshow_i = function () {
		var t = new eui.Image();
		this.l_buyshow = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 213;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "l_buyshow_png";
		t.width = 166;
		t.x = 1384;
		t.y = 136.29;
		return t;
	};
	_proto.buy_show_i = function () {
		var t = new eui.Button();
		this.buy_show = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 210;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 160;
		t.x = 1386.5;
		t.y = 135.29;
		t.skinName = menuSkin$Skin19;
		return t;
	};
	_proto.l_yes_i = function () {
		var t = new eui.Image();
		this.l_yes = t;
		t.height = 20;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 20;
		t.x = 1566;
		t.y = 988;
		return t;
	};
	_proto.imagine_i = function () {
		var t = new eui.Group();
		this.imagine = t;
		t.height = 200;
		t.width = 200;
		t.x = 377;
		t.y = 147;
		t.elementsContent = [this.i_img_i(),this.i_imagine_i()];
		return t;
	};
	_proto.i_img_i = function () {
		var t = new eui.Image();
		this.i_img = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "thought_png";
		t.x = 819.53;
		t.y = 286;
		return t;
	};
	_proto.i_imagine_i = function () {
		var t = new eui.Image();
		this.i_imagine = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = -5.08;
		t.height = 127;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "";
		t.width = 122;
		t.x = 889.74;
		t.y = 308.35;
		return t;
	};
	_proto.cvs_i = function () {
		var t = new eui.Group();
		this.cvs = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 654;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 524;
		t.x = 845.53;
		t.y = 137;
		return t;
	};
	_proto.yaoshui_i = function () {
		var t = new eui.Group();
		this.yaoshui = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 1.92;
		t.height = 384;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 865;
		t.x = 88;
		t.y = 97.51;
		t.elementsContent = [this.l_p1_i(),this.l_p2_i(),this.l_p3_i(),this.l_p4_i(),this.l_p5_i(),this.l_p6_i(),this.l_p7_i(),this.l_p8_i(),this.l_piBgeye_i(),this.l_pSkin_i(),this.l_pDye_i(),this.l_pcolar_i(),this.p1_i(),this.p2_i(),this.p3_i(),this.p4_i(),this.p5_i(),this.p6_i(),this.p7_i(),this.p8_i(),this.p_bigeye_i(),this.p_Skin_i(),this.p_dye_i(),this.p_colar_i()];
		return t;
	};
	_proto.l_p1_i = function () {
		var t = new eui.Image();
		this.l_p1 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 85;
		t.x = -48;
		t.y = -50;
		return t;
	};
	_proto.l_p2_i = function () {
		var t = new eui.Image();
		this.l_p2 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 100;
		t.y = -51;
		return t;
	};
	_proto.l_p3_i = function () {
		var t = new eui.Image();
		this.l_p3 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 254;
		t.y = -54;
		return t;
	};
	_proto.l_p4_i = function () {
		var t = new eui.Image();
		this.l_p4 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 677;
		t.y = -52;
		return t;
	};
	_proto.l_p5_i = function () {
		var t = new eui.Image();
		this.l_p5 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = -39;
		t.y = 202;
		return t;
	};
	_proto.l_p6_i = function () {
		var t = new eui.Image();
		this.l_p6 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 193;
		t.source = "l_yao_1_png";
		t.width = 113;
		t.x = 99.5;
		t.y = 196;
		return t;
	};
	_proto.l_p7_i = function () {
		var t = new eui.Image();
		this.l_p7 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 193;
		t.source = "l_yao_1_png";
		t.width = 113;
		t.x = 258;
		t.y = 202.43;
		return t;
	};
	_proto.l_p8_i = function () {
		var t = new eui.Image();
		this.l_p8 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 684;
		t.y = 202.84;
		return t;
	};
	_proto.l_piBgeye_i = function () {
		var t = new eui.Image();
		this.l_piBgeye = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 198;
		t.source = "l_bigeye_png";
		t.width = 132;
		t.x = 814;
		t.y = -56;
		return t;
	};
	_proto.l_pSkin_i = function () {
		var t = new eui.Image();
		this.l_pSkin = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 212;
		t.source = "l_skin_png";
		t.width = 112;
		t.x = 989;
		t.y = -37;
		return t;
	};
	_proto.l_pDye_i = function () {
		var t = new eui.Image();
		this.l_pDye = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 106;
		t.source = "l_dye_png";
		t.width = 126;
		t.x = 812;
		t.y = 287.41;
		return t;
	};
	_proto.l_pcolar_i = function () {
		var t = new eui.Image();
		this.l_pcolar = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 154;
		t.source = "l_colar_png";
		t.width = 134;
		t.x = 982;
		t.y = 241;
		return t;
	};
	_proto.p1_i = function () {
		var t = new eui.Image();
		this.p1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p1";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p1_png";
		t.touchEnabled = true;
		t.x = -49;
		t.y = -45;
		return t;
	};
	_proto.p2_i = function () {
		var t = new eui.Image();
		this.p2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p2";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p2_png";
		t.touchEnabled = true;
		t.x = 103;
		t.y = -48;
		return t;
	};
	_proto.p3_i = function () {
		var t = new eui.Image();
		this.p3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p3";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p3_png";
		t.touchEnabled = true;
		t.x = 258.15;
		t.y = -45;
		return t;
	};
	_proto.p4_i = function () {
		var t = new eui.Image();
		this.p4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p4";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p4_png";
		t.touchEnabled = true;
		t.x = 677.6;
		t.y = -45;
		return t;
	};
	_proto.p5_i = function () {
		var t = new eui.Image();
		this.p5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p5";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p5_png";
		t.touchEnabled = true;
		t.x = -35;
		t.y = 201;
		return t;
	};
	_proto.p6_i = function () {
		var t = new eui.Image();
		this.p6 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p6";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p6_png";
		t.touchEnabled = true;
		t.x = 110;
		t.y = 206;
		return t;
	};
	_proto.p7_i = function () {
		var t = new eui.Image();
		this.p7 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p7";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p7_png";
		t.touchEnabled = true;
		t.x = 267.87;
		t.y = 204;
		return t;
	};
	_proto.p8_i = function () {
		var t = new eui.Image();
		this.p8 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 204;
		t.name = "p8";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p8_png";
		t.touchEnabled = true;
		t.x = 688.48;
		t.y = 195;
		return t;
	};
	_proto.p_bigeye_i = function () {
		var t = new eui.Image();
		this.p_bigeye = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 184;
		t.source = "p_Bigeye_png";
		t.width = 112;
		t.x = 820.96;
		t.y = -46;
		return t;
	};
	_proto.p_Skin_i = function () {
		var t = new eui.Image();
		this.p_Skin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 166;
		t.source = "p_Skin_png";
		t.width = 106;
		t.x = 997;
		t.y = -28;
		return t;
	};
	_proto.p_dye_i = function () {
		var t = new eui.Image();
		this.p_dye = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 92;
		t.source = "p_dye_png";
		t.width = 110;
		t.x = 822.4;
		t.y = 291;
		return t;
	};
	_proto.p_colar_i = function () {
		var t = new eui.Image();
		this.p_colar = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 142;
		t.source = "p_Colar_png";
		t.width = 138;
		t.x = 989;
		t.y = 249;
		return t;
	};
	_proto.notice_i = function () {
		var t = new eui.Group();
		this.notice = t;
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 200;
		t.x = 715;
		t.y = 215;
		t.elementsContent = [this._Image4_i(),this.note_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 348.84;
		t.source = "n30_png";
		t.width = 567.03;
		t.x = -112.42;
		t.y = -57.03;
		return t;
	};
	_proto.note_i = function () {
		var t = new eui.Label();
		this.note = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 77.06;
		t.text = "第 1 天 开始啦！";
		t.textColor = 0xffefcc;
		t.width = 273.94;
		t.x = 43.67;
		t.y = 75.21;
		return t;
	};
	_proto.med_btn_i = function () {
		var t = new eui.Button();
		this.med_btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 453.64;
		t.y = 239.14;
		t.skinName = menuSkin$Skin20;
		return t;
	};
	_proto.users_i = function () {
		var t = new eui.Group();
		this.users = t;
		t.height = 200;
		t.width = 200;
		t.x = 1310;
		t.y = 456;
		t.elementsContent = [this.new_user_i(),this.u1_user_i(),this.u2_user_i(),this.u3_user_i(),this.u4_user_i()];
		return t;
	};
	_proto.new_user_i = function () {
		var t = new eui.Group();
		this.new_user = t;
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 200;
		t.x = -131.26;
		t.y = -3.41;
		return t;
	};
	_proto.u1_user_i = function () {
		var t = new eui.Group();
		this.u1_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 50;
		t.x = 257;
		t.y = -80;
		return t;
	};
	_proto.u2_user_i = function () {
		var t = new eui.Group();
		this.u2_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 50;
		t.x = 306;
		t.y = -80;
		return t;
	};
	_proto.u3_user_i = function () {
		var t = new eui.Group();
		this.u3_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 50;
		t.x = 377;
		t.y = -80;
		return t;
	};
	_proto.u4_user_i = function () {
		var t = new eui.Group();
		this.u4_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 51;
		t.x = 456;
		t.y = -80;
		return t;
	};
	_proto.mix_bar_i = function () {
		var t = new eui.ProgressBar();
		this.mix_bar = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.direction = "btt";
		t.height = 156;
		t.maximum = 500;
		t.skinName = "ProgressBarSkin_2";
		t.value = 0;
		t.width = 46;
		t.x = 224;
		t.y = 787;
		return t;
	};
	_proto.communication_i = function () {
		var t = new eui.Group();
		this.communication = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 54;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 128;
		t.x = 276;
		t.y = 952;
		t.elementsContent = [this._Image5_i(),this.dialog_i(),this.ask_panel_i(),this.content_i(),this.somebody_i(),this.yes_i(),this.no_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "com_bgp_png";
		t.x = -276;
		t.y = -71.5;
		return t;
	};
	_proto.dialog_i = function () {
		var t = new eui.Label();
		this.dialog = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 63.33;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "";
		t.textColor = 0x000000;
		t.width = 119.45;
		t.x = -215;
		t.y = -14.999999999999886;
		return t;
	};
	_proto.ask_panel_i = function () {
		var t = new eui.Group();
		this.ask_panel = t;
		t.anchorOffsetX = 0;
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 1400;
		t.x = -223;
		t.y = 0;
		t.elementsContent = [this._Image6_i(),this._Label1_i(),this._Label2_i()];
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "bg2_jpg";
		t.width = 1400;
		t.x = 1;
		t.y = 0;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "Label";
		t.x = 32;
		t.y = -26;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 92;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 100;
		t.text = "想把他带走吗？";
		t.textColor = 0x000000;
		t.width = 942;
		t.x = 81;
		t.y = 41;
		return t;
	};
	_proto.content_i = function () {
		var t = new eui.Label();
		this.content = t;
		t.anchorOffsetX = -6.13;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 65.73;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "balalalallalla1";
		t.textColor = 0x000000;
		t.width = 991.85;
		t.x = 211.02;
		t.y = 17.27;
		return t;
	};
	_proto.somebody_i = function () {
		var t = new eui.Label();
		this.somebody = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 99.63;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "name1";
		t.textColor = 0x000000;
		t.width = 155.64;
		t.x = 39.03;
		t.y = 18.27;
		return t;
	};
	_proto.yes_i = function () {
		var t = new eui.Button();
		this.yes = t;
		t.anchorOffsetX = -27.27;
		t.anchorOffsetY = -3.03;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 1197.27;
		t.y = 10.029999999999973;
		t.skinName = menuSkin$Skin21;
		return t;
	};
	_proto.no_i = function () {
		var t = new eui.Button();
		this.no = t;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 1380;
		t.y = 6;
		t.skinName = menuSkin$Skin22;
		return t;
	};
	_proto.tucao_i = function () {
		var t = new eui.Group();
		this.tucao = t;
		t.anchorOffsetY = 0;
		t.height = 96;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 200;
		t.x = 377;
		t.y = 935;
		t.elementsContent = [this._Image7_i(),this.tc_label_i(),this._Label3_i()];
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "com_bgp1_png";
		t.visible = false;
		t.x = -372.5;
		t.y = -51.110000000000014;
		return t;
	};
	_proto.tc_label_i = function () {
		var t = new eui.Label();
		this.tc_label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 151;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "NaN";
		t.textColor = 0x000000;
		t.width = 171;
		t.x = 1015.53;
		t.y = -483;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 46;
		t.text = "顾客";
		t.textColor = 0x000000;
		t.visible = false;
		t.width = 89;
		t.x = -34;
		t.y = 49;
		return t;
	};
	_proto.panel1_i = function () {
		var t = new eui.Group();
		this.panel1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 800;
		t.visible = false;
		t.width = 1200;
		t.x = 289;
		t.y = 113;
		t.elementsContent = [this._Image8_i(),this.show_0_i(),this.show_1_i(),this.show_2_i(),this.show_3_i(),this.show_4_i(),this.show_5_i(),this.fanhui_i()];
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.height = 800;
		t.source = "buy_show_bg_png";
		t.width = 1200;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.show_0_i = function () {
		var t = new eui.Image();
		this.show_0 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 150;
		t.y = 180;
		return t;
	};
	_proto.show_1_i = function () {
		var t = new eui.Image();
		this.show_1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 450;
		t.y = 180;
		return t;
	};
	_proto.show_2_i = function () {
		var t = new eui.Image();
		this.show_2 = t;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 760;
		t.y = 180;
		return t;
	};
	_proto.show_3_i = function () {
		var t = new eui.Image();
		this.show_3 = t;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 150;
		t.y = 450;
		return t;
	};
	_proto.show_4_i = function () {
		var t = new eui.Image();
		this.show_4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 450;
		t.y = 450;
		return t;
	};
	_proto.show_5_i = function () {
		var t = new eui.Image();
		this.show_5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 760;
		t.y = 450;
		return t;
	};
	_proto.fanhui_i = function () {
		var t = new eui.Button();
		this.fanhui = t;
		t.label = "";
		t.x = 1073;
		t.y = 74;
		t.skinName = menuSkin$Skin23;
		return t;
	};
	_proto.note_panel_i = function () {
		var t = new eui.Group();
		this.note_panel = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 600;
		t.visible = false;
		t.width = 900;
		t.x = 634;
		t.y = 202;
		t.elementsContent = [this._Image9_i(),this.cha_i()];
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "notes_png";
		t.x = -600;
		t.y = -202;
		return t;
	};
	_proto.cha_i = function () {
		var t = new eui.Button();
		this.cha = t;
		t.label = "";
		t.x = 1123.06;
		t.y = -100;
		t.skinName = menuSkin$Skin24;
		return t;
	};
	_proto.leader1_i = function () {
		var t = new eui.Group();
		this.leader1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 166;
		t.visible = false;
		t.width = 234;
		t.x = 1299;
		t.y = 194;
		t.elementsContent = [this._Image10_i(),this.lead1_i(),this.cover1_i()];
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.source = "n32_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.lead1_i = function () {
		var t = new eui.Label();
		this.lead1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 56;
		t.textColor = 0xffefcc;
		t.width = 386;
		t.x = 41;
		t.y = 23;
		return t;
	};
	_proto.cover1_i = function () {
		var t = new eui.Image();
		this.cover1 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 3092.67;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "streak_png";
		t.width = 3923.67;
		t.x = -1291.03;
		t.y = -154.67;
		return t;
	};
	_proto.leader2_i = function () {
		var t = new eui.Group();
		this.leader2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 166;
		t.visible = false;
		t.width = 555.21;
		t.x = 884;
		t.y = 764.93;
		t.elementsContent = [this._Image11_i(),this.lead2_i()];
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.source = "n33_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.lead2_i = function () {
		var t = new eui.Label();
		this.lead2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 86;
		t.textColor = 0xffefcc;
		t.width = 416;
		t.x = 79;
		t.y = 19;
		return t;
	};
	_proto.leader3_i = function () {
		var t = new eui.Group();
		this.leader3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 166;
		t.visible = false;
		t.width = 234;
		t.x = 1435;
		t.y = 153;
		t.elementsContent = [this._Image12_i(),this.lead3_i(),this.cover3_i()];
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.source = "n31_png";
		t.x = -90;
		t.y = 0;
		return t;
	};
	_proto.lead3_i = function () {
		var t = new eui.Label();
		this.lead3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 93;
		t.textColor = 0xffefcc;
		t.width = 521;
		t.x = -55;
		t.y = 41;
		return t;
	};
	_proto.cover3_i = function () {
		var t = new eui.Image();
		this.cover3 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1509.33;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "streak_png";
		t.width = 2523.67;
		t.x = -1454.67;
		t.y = -171.33;
		return t;
	};
	_proto.tt_i = function () {
		var t = new eui.Group();
		this.tt = t;
		t.height = 200;
		t.visible = false;
		t.width = 200;
		t.x = 842;
		t.y = 802;
		t.elementsContent = [this.test_i(),this.cover0_i()];
		return t;
	};
	_proto.test_i = function () {
		var t = new eui.Image();
		this.test = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "thought_png";
		t.visible = false;
		t.x = 619;
		t.y = -544;
		return t;
	};
	_proto.cover0_i = function () {
		var t = new eui.Image();
		this.cover0 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1234.33;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "streak_png";
		t.visible = false;
		t.width = 282;
		t.x = 728;
		t.y = 42;
		return t;
	};
	_proto.finish_i = function () {
		var t = new eui.Group();
		this.finish = t;
		t.height = 200;
		t.visible = false;
		t.width = 200;
		t.x = 844;
		t.y = 326;
		t.elementsContent = [this.finish_bg_i(),this.poison_i(),this.finish_l_i(),this.finish_b_i(),this.finish_z_i(),this.finish_f_i()];
		return t;
	};
	_proto.finish_bg_i = function () {
		var t = new eui.Image();
		this.finish_bg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 732;
		t.source = "reward_png";
		t.width = 1156;
		t.x = -346;
		t.y = -174;
		return t;
	};
	_proto.poison_i = function () {
		var t = new eui.Image();
		this.poison = t;
		t.anchorOffsetX = 0;
		t.height = 398;
		t.rotation = 345.16;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "";
		t.width = 271.95;
		t.x = 245;
		t.y = 23;
		return t;
	};
	_proto.finish_l_i = function () {
		var t = new eui.Label();
		this.finish_l = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 39;
		t.text = "Label";
		t.textColor = 0x000000;
		t.width = 307;
		t.x = -166;
		t.y = 23;
		return t;
	};
	_proto.finish_b_i = function () {
		var t = new eui.Button();
		this.finish_b = t;
		t.enabled = true;
		t.height = 120;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 120;
		t.x = 563;
		t.y = -96;
		t.skinName = menuSkin$Skin25;
		return t;
	};
	_proto.finish_z_i = function () {
		var t = new eui.Label();
		this.finish_z = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 204;
		t.text = "Label";
		t.textColor = 0x000000;
		t.width = 238;
		t.x = -152;
		t.y = 77;
		return t;
	};
	_proto.finish_f_i = function () {
		var t = new eui.Label();
		this.finish_f = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 76;
		t.text = "混乱之主";
		t.textColor = 0x000000;
		t.width = 135;
		t.x = -5;
		t.y = 308;
		return t;
	};
	_proto.leader_i = function () {
		var t = new eui.Group();
		this.leader = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 245.45;
		t.visible = false;
		t.width = 287.88;
		t.x = 880;
		t.y = 679;
		t.elementsContent = [this._Image13_i(),this.lead_i(),this.cover_i()];
		return t;
	};
	_proto._Image13_i = function () {
		var t = new eui.Image();
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 427.63;
		t.source = "n30_png";
		t.width = 570.06;
		t.x = -133.34;
		t.y = -330.3;
		return t;
	};
	_proto.lead_i = function () {
		var t = new eui.Label();
		this.lead = t;
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 444.24;
		t.text = "欢迎来到你的工作间~ 这是你制作满足女孩们幻想的男性的地方~";
		t.textColor = 0xffefcc;
		t.width = 293.93;
		t.x = 10;
		t.y = -214.24;
		return t;
	};
	_proto.cover_i = function () {
		var t = new eui.Image();
		this.cover = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1509.33;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "streak_png";
		t.width = 2523.67;
		t.x = -1454.67;
		t.y = -171.33;
		return t;
	};
	_proto.endpic_i = function () {
		var t = new eui.Image();
		this.endpic = t;
		t.height = 1080;
		t.source = "end_png";
		t.visible = false;
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		return t;
	};
	return menuSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/menu.exml'] = window.menuSkin = (function (_super) {
	__extends(menuSkin, _super);
	var menuSkin$Skin26 = 	(function (_super) {
		__extends(menuSkin$Skin26, _super);
		function menuSkin$Skin26() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin26.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "close_door_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin26;
	})(eui.Skin);

	var menuSkin$Skin27 = 	(function (_super) {
		__extends(menuSkin$Skin27, _super);
		function menuSkin$Skin27() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin27.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "setting_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin27;
	})(eui.Skin);

	var menuSkin$Skin28 = 	(function (_super) {
		__extends(menuSkin$Skin28, _super);
		function menuSkin$Skin28() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin28.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "show_buyer_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin28;
	})(eui.Skin);

	var menuSkin$Skin29 = 	(function (_super) {
		__extends(menuSkin$Skin29, _super);
		function menuSkin$Skin29() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin29.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "compare_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin29;
	})(eui.Skin);

	var menuSkin$Skin30 = 	(function (_super) {
		__extends(menuSkin$Skin30, _super);
		function menuSkin$Skin30() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin30.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "shi_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin30;
	})(eui.Skin);

	var menuSkin$Skin31 = 	(function (_super) {
		__extends(menuSkin$Skin31, _super);
		function menuSkin$Skin31() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin31.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "fou_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin31;
	})(eui.Skin);

	var menuSkin$Skin32 = 	(function (_super) {
		__extends(menuSkin$Skin32, _super);
		function menuSkin$Skin32() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin32.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "cha_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin32;
	})(eui.Skin);

	var menuSkin$Skin33 = 	(function (_super) {
		__extends(menuSkin$Skin33, _super);
		function menuSkin$Skin33() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin33.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "cha_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin33;
	})(eui.Skin);

	var menuSkin$Skin34 = 	(function (_super) {
		__extends(menuSkin$Skin34, _super);
		function menuSkin$Skin34() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = menuSkin$Skin34.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "reward_return_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.fontFamily = "miao";
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return menuSkin$Skin34;
	})(eui.Skin);

	function menuSkin() {
		_super.call(this);
		this.skinParts = ["fraction","bg","equip","l_guo","Clock","ghost_pic","ghost","factory","progress0","miss_Num","guo","l_door","door_btn","setting","m_num","mass","l_note","l_buyshow","buy_show","l_yes","i_img","i_imagine","imagine","cvs","l_p1","l_p2","l_p3","l_p4","l_p5","l_p6","l_p7","l_p8","l_piBgeye","l_pSkin","l_pDye","l_pcolar","p1","p2","p3","p4","p5","p6","p7","p8","p_bigeye","p_Skin","p_dye","p_colar","yaoshui","med_btn","note","notice","u1_user","u2_user","u3_user","u4_user","new_user","users","mix_bar","dialog","ask_panel","content","somebody","yes","no","communication","whole_layout","tc_label","tucao","show_0","show_1","show_2","show_3","show_4","show_5","fanhui","panel1","cha","note_panel","test","cover0","tt","finish_bg","poison","finish_l","finish_b","finish_z","finish_f","finish","lead","cover","leader","endpic"];
		
		this.height = 1080;
		this.width = 1920;
		this.fraction_i();
		this.elementsContent = [this.whole_layout_i(),this.tucao_i(),this.panel1_i(),this.note_panel_i(),this.tt_i(),this.finish_i(),this.leader_i(),this.endpic_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.head"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object1,"y");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [94],[],this._Object2,"y");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [88],[],this._Object3,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [82],[],this._Object4,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, [76],[],this._Object5,"y");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [70],[],this._Object6,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [64],[],this._Object7,"y");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [58],[],this._Object8,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [52],[],this._Object9,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.neck"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object11,"alpha");
		eui.Binding.$bindProperties(this, [17],[],this._Object11,"width");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, [15],[],this._Object12,"width");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object13,"alpha");
		eui.Binding.$bindProperties(this, [13],[],this._Object13,"width");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object14,"alpha");
		eui.Binding.$bindProperties(this, [11],[],this._Object14,"width");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object15,"alpha");
		eui.Binding.$bindProperties(this, [9],[],this._Object15,"width");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object16,"alpha");
		eui.Binding.$bindProperties(this, [7],[],this._Object16,"width");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object17,"alpha");
		eui.Binding.$bindProperties(this, [7],[],this._Object17,"width");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object18,"alpha");
		eui.Binding.$bindProperties(this, [5],[],this._Object18,"width");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object19,"alpha");
		eui.Binding.$bindProperties(this, [3],[],this._Object19,"width");
		eui.Binding.$bindProperties(this, [0],[],this._Object20,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.body"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object21,"alpha");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object22,"alpha");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object23,"alpha");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object24,"alpha");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object25,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object26,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.left_arm"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object27,"alpha");
		eui.Binding.$bindProperties(this, [22],[],this._Object27,"width");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object28,"alpha");
		eui.Binding.$bindProperties(this, [17],[],this._Object28,"width");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object29,"alpha");
		eui.Binding.$bindProperties(this, [12],[],this._Object29,"width");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object30,"alpha");
		eui.Binding.$bindProperties(this, [7],[],this._Object30,"width");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object31,"alpha");
		eui.Binding.$bindProperties(this, [2],[],this._Object31,"width");
		eui.Binding.$bindProperties(this, [0],[],this._Object32,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.right_arm"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object33,"alpha");
		eui.Binding.$bindProperties(this, [22],[],this._Object33,"width");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object34,"alpha");
		eui.Binding.$bindProperties(this, [17],[],this._Object34,"width");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object35,"alpha");
		eui.Binding.$bindProperties(this, [12],[],this._Object35,"width");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object36,"alpha");
		eui.Binding.$bindProperties(this, [5],[],this._Object36,"width");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object37,"alpha");
		eui.Binding.$bindProperties(this, [3],[],this._Object37,"width");
		eui.Binding.$bindProperties(this, [0],[],this._Object38,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.left_hand"],[0],this._TweenItem6,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object39,"alpha");
		eui.Binding.$bindProperties(this, [118],[],this._Object39,"x");
		eui.Binding.$bindProperties(this, [516],[],this._Object39,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object40,"alpha");
		eui.Binding.$bindProperties(this, [112],[],this._Object40,"x");
		eui.Binding.$bindProperties(this, [522],[],this._Object40,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object41,"alpha");
		eui.Binding.$bindProperties(this, [106],[],this._Object41,"x");
		eui.Binding.$bindProperties(this, [528],[],this._Object41,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object42,"alpha");
		eui.Binding.$bindProperties(this, [100],[],this._Object42,"x");
		eui.Binding.$bindProperties(this, [534],[],this._Object42,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object43,"alpha");
		eui.Binding.$bindProperties(this, [94],[],this._Object43,"x");
		eui.Binding.$bindProperties(this, [540],[],this._Object43,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object44,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.left_leg"],[0],this._TweenItem7,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object45,"alpha");
		eui.Binding.$bindProperties(this, [587],[],this._Object45,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object46,"alpha");
		eui.Binding.$bindProperties(this, [593],[],this._Object46,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object47,"alpha");
		eui.Binding.$bindProperties(this, [599],[],this._Object47,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object48,"alpha");
		eui.Binding.$bindProperties(this, [605],[],this._Object48,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object49,"alpha");
		eui.Binding.$bindProperties(this, [611],[],this._Object49,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object50,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.right_leg"],[0],this._TweenItem8,"target");
		eui.Binding.$bindProperties(this, [600],[],this._Object51,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object52,"alpha");
		eui.Binding.$bindProperties(this, [606],[],this._Object52,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object53,"alpha");
		eui.Binding.$bindProperties(this, [612],[],this._Object53,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object54,"alpha");
		eui.Binding.$bindProperties(this, [624],[],this._Object54,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object55,"alpha");
		eui.Binding.$bindProperties(this, [624],[],this._Object55,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object56,"alpha");
		eui.Binding.$bindProperties(this, ["hostComponent.right_hand"],[0],this._TweenItem9,"target");
		eui.Binding.$bindProperties(this, [0.9],[],this._Object57,"alpha");
		eui.Binding.$bindProperties(this, [505],[],this._Object57,"y");
		eui.Binding.$bindProperties(this, [0.7],[],this._Object58,"alpha");
		eui.Binding.$bindProperties(this, [511],[],this._Object58,"y");
		eui.Binding.$bindProperties(this, [0.5],[],this._Object59,"alpha");
		eui.Binding.$bindProperties(this, [517],[],this._Object59,"y");
		eui.Binding.$bindProperties(this, [0.3],[],this._Object60,"alpha");
		eui.Binding.$bindProperties(this, [523],[],this._Object60,"y");
		eui.Binding.$bindProperties(this, [0.1],[],this._Object61,"alpha");
		eui.Binding.$bindProperties(this, [529],[],this._Object61,"y");
		eui.Binding.$bindProperties(this, [0],[],this._Object62,"alpha");
	}
	var _proto = menuSkin.prototype;

	_proto.fraction_i = function () {
		var t = new egret.tween.TweenGroup();
		this.fraction = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i(),this._TweenItem5_i(),this._TweenItem6_i(),this._TweenItem7_i(),this._TweenItem8_i(),this._TweenItem9_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Wait1_i(),this._Set1_i(),this._Wait2_i(),this._Set2_i(),this._Wait3_i(),this._Set3_i(),this._Wait4_i(),this._Set4_i(),this._Wait5_i(),this._Set5_i(),this._Wait6_i(),this._Set6_i(),this._Wait7_i(),this._Set7_i(),this._Wait8_i(),this._Set8_i(),this._Wait9_i(),this._Set9_i(),this._Wait10_i(),this._Set10_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait8_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._Wait9_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait10_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait11_i(),this._Set11_i(),this._Wait12_i(),this._Set12_i(),this._Wait13_i(),this._Set13_i(),this._Wait14_i(),this._Set14_i(),this._Wait15_i(),this._Set15_i(),this._Wait16_i(),this._Set16_i(),this._Wait17_i(),this._Set17_i(),this._Wait18_i(),this._Set18_i(),this._Wait19_i(),this._Set19_i(),this._Wait20_i(),this._Set20_i()];
		return t;
	};
	_proto._Wait11_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Wait12_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set12_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._Wait13_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set13_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._Wait14_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set14_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._Wait15_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set15_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto._Wait16_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set16_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto._Wait17_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set17_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._Wait18_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set18_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._Wait19_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set19_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object19_i();
		return t;
	};
	_proto._Object19_i = function () {
		var t = {};
		this._Object19 = t;
		return t;
	};
	_proto._Wait20_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set20_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object20_i();
		return t;
	};
	_proto._Object20_i = function () {
		var t = {};
		this._Object20 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Wait21_i(),this._Set21_i(),this._Wait22_i(),this._Set22_i(),this._Wait23_i(),this._Set23_i(),this._Wait24_i(),this._Set24_i(),this._Wait25_i(),this._Set25_i(),this._Wait26_i(),this._Set26_i()];
		return t;
	};
	_proto._Wait21_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set21_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object21_i();
		return t;
	};
	_proto._Object21_i = function () {
		var t = {};
		this._Object21 = t;
		return t;
	};
	_proto._Wait22_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set22_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object22_i();
		return t;
	};
	_proto._Object22_i = function () {
		var t = {};
		this._Object22 = t;
		return t;
	};
	_proto._Wait23_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set23_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object23_i();
		return t;
	};
	_proto._Object23_i = function () {
		var t = {};
		this._Object23 = t;
		return t;
	};
	_proto._Wait24_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set24_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object24_i();
		return t;
	};
	_proto._Object24_i = function () {
		var t = {};
		this._Object24 = t;
		return t;
	};
	_proto._Wait25_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set25_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object25_i();
		return t;
	};
	_proto._Object25_i = function () {
		var t = {};
		this._Object25 = t;
		return t;
	};
	_proto._Wait26_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set26_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object26_i();
		return t;
	};
	_proto._Object26_i = function () {
		var t = {};
		this._Object26 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Wait27_i(),this._Set27_i(),this._Wait28_i(),this._Set28_i(),this._Wait29_i(),this._Set29_i(),this._Wait30_i(),this._Set30_i(),this._Wait31_i(),this._Set31_i(),this._Wait32_i(),this._Set32_i()];
		return t;
	};
	_proto._Wait27_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set27_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object27_i();
		return t;
	};
	_proto._Object27_i = function () {
		var t = {};
		this._Object27 = t;
		return t;
	};
	_proto._Wait28_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set28_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object28_i();
		return t;
	};
	_proto._Object28_i = function () {
		var t = {};
		this._Object28 = t;
		return t;
	};
	_proto._Wait29_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set29_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object29_i();
		return t;
	};
	_proto._Object29_i = function () {
		var t = {};
		this._Object29 = t;
		return t;
	};
	_proto._Wait30_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set30_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object30_i();
		return t;
	};
	_proto._Object30_i = function () {
		var t = {};
		this._Object30 = t;
		return t;
	};
	_proto._Wait31_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set31_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object31_i();
		return t;
	};
	_proto._Object31_i = function () {
		var t = {};
		this._Object31 = t;
		return t;
	};
	_proto._Wait32_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set32_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object32_i();
		return t;
	};
	_proto._Object32_i = function () {
		var t = {};
		this._Object32 = t;
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Wait33_i(),this._Set33_i(),this._Wait34_i(),this._Set34_i(),this._Wait35_i(),this._Set35_i(),this._Wait36_i(),this._Set36_i(),this._Wait37_i(),this._Set37_i(),this._Wait38_i(),this._Set38_i()];
		return t;
	};
	_proto._Wait33_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set33_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object33_i();
		return t;
	};
	_proto._Object33_i = function () {
		var t = {};
		this._Object33 = t;
		return t;
	};
	_proto._Wait34_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set34_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object34_i();
		return t;
	};
	_proto._Object34_i = function () {
		var t = {};
		this._Object34 = t;
		return t;
	};
	_proto._Wait35_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set35_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object35_i();
		return t;
	};
	_proto._Object35_i = function () {
		var t = {};
		this._Object35 = t;
		return t;
	};
	_proto._Wait36_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set36_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object36_i();
		return t;
	};
	_proto._Object36_i = function () {
		var t = {};
		this._Object36 = t;
		return t;
	};
	_proto._Wait37_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set37_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object37_i();
		return t;
	};
	_proto._Object37_i = function () {
		var t = {};
		this._Object37 = t;
		return t;
	};
	_proto._Wait38_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set38_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object38_i();
		return t;
	};
	_proto._Object38_i = function () {
		var t = {};
		this._Object38 = t;
		return t;
	};
	_proto._TweenItem6_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem6 = t;
		t.paths = [this._Wait39_i(),this._Set39_i(),this._Wait40_i(),this._Set40_i(),this._Wait41_i(),this._Set41_i(),this._Wait42_i(),this._Set42_i(),this._Wait43_i(),this._Set43_i(),this._Wait44_i(),this._Set44_i()];
		return t;
	};
	_proto._Wait39_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set39_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object39_i();
		return t;
	};
	_proto._Object39_i = function () {
		var t = {};
		this._Object39 = t;
		return t;
	};
	_proto._Wait40_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set40_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object40_i();
		return t;
	};
	_proto._Object40_i = function () {
		var t = {};
		this._Object40 = t;
		return t;
	};
	_proto._Wait41_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set41_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object41_i();
		return t;
	};
	_proto._Object41_i = function () {
		var t = {};
		this._Object41 = t;
		return t;
	};
	_proto._Wait42_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set42_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object42_i();
		return t;
	};
	_proto._Object42_i = function () {
		var t = {};
		this._Object42 = t;
		return t;
	};
	_proto._Wait43_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set43_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object43_i();
		return t;
	};
	_proto._Object43_i = function () {
		var t = {};
		this._Object43 = t;
		return t;
	};
	_proto._Wait44_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set44_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object44_i();
		return t;
	};
	_proto._Object44_i = function () {
		var t = {};
		this._Object44 = t;
		return t;
	};
	_proto._TweenItem7_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem7 = t;
		t.paths = [this._Wait45_i(),this._Set45_i(),this._Wait46_i(),this._Set46_i(),this._Wait47_i(),this._Set47_i(),this._Wait48_i(),this._Set48_i(),this._Wait49_i(),this._Set49_i(),this._Wait50_i(),this._Set50_i()];
		return t;
	};
	_proto._Wait45_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set45_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object45_i();
		return t;
	};
	_proto._Object45_i = function () {
		var t = {};
		this._Object45 = t;
		return t;
	};
	_proto._Wait46_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set46_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object46_i();
		return t;
	};
	_proto._Object46_i = function () {
		var t = {};
		this._Object46 = t;
		return t;
	};
	_proto._Wait47_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set47_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object47_i();
		return t;
	};
	_proto._Object47_i = function () {
		var t = {};
		this._Object47 = t;
		return t;
	};
	_proto._Wait48_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set48_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object48_i();
		return t;
	};
	_proto._Object48_i = function () {
		var t = {};
		this._Object48 = t;
		return t;
	};
	_proto._Wait49_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set49_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object49_i();
		return t;
	};
	_proto._Object49_i = function () {
		var t = {};
		this._Object49 = t;
		return t;
	};
	_proto._Wait50_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set50_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object50_i();
		return t;
	};
	_proto._Object50_i = function () {
		var t = {};
		this._Object50 = t;
		return t;
	};
	_proto._TweenItem8_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem8 = t;
		t.paths = [this._Wait51_i(),this._Set51_i(),this._Wait52_i(),this._Set52_i(),this._Wait53_i(),this._Set53_i(),this._Wait54_i(),this._Set54_i(),this._Wait55_i(),this._Set55_i(),this._Wait56_i(),this._Set56_i()];
		return t;
	};
	_proto._Wait51_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set51_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object51_i();
		return t;
	};
	_proto._Object51_i = function () {
		var t = {};
		this._Object51 = t;
		return t;
	};
	_proto._Wait52_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set52_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object52_i();
		return t;
	};
	_proto._Object52_i = function () {
		var t = {};
		this._Object52 = t;
		return t;
	};
	_proto._Wait53_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set53_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object53_i();
		return t;
	};
	_proto._Object53_i = function () {
		var t = {};
		this._Object53 = t;
		return t;
	};
	_proto._Wait54_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set54_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object54_i();
		return t;
	};
	_proto._Object54_i = function () {
		var t = {};
		this._Object54 = t;
		return t;
	};
	_proto._Wait55_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set55_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object55_i();
		return t;
	};
	_proto._Object55_i = function () {
		var t = {};
		this._Object55 = t;
		return t;
	};
	_proto._Wait56_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set56_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object56_i();
		return t;
	};
	_proto._Object56_i = function () {
		var t = {};
		this._Object56 = t;
		return t;
	};
	_proto._TweenItem9_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem9 = t;
		t.paths = [this._Wait57_i(),this._Set57_i(),this._Wait58_i(),this._Set58_i(),this._Wait59_i(),this._Set59_i(),this._Wait60_i(),this._Set60_i(),this._Wait61_i(),this._Set61_i(),this._Wait62_i(),this._Set62_i()];
		return t;
	};
	_proto._Wait57_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set57_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object57_i();
		return t;
	};
	_proto._Object57_i = function () {
		var t = {};
		this._Object57 = t;
		return t;
	};
	_proto._Wait58_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set58_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object58_i();
		return t;
	};
	_proto._Object58_i = function () {
		var t = {};
		this._Object58 = t;
		return t;
	};
	_proto._Wait59_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set59_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object59_i();
		return t;
	};
	_proto._Object59_i = function () {
		var t = {};
		this._Object59 = t;
		return t;
	};
	_proto._Wait60_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set60_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object60_i();
		return t;
	};
	_proto._Object60_i = function () {
		var t = {};
		this._Object60 = t;
		return t;
	};
	_proto._Wait61_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 200;
		return t;
	};
	_proto._Set61_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object61_i();
		return t;
	};
	_proto._Object61_i = function () {
		var t = {};
		this._Object61 = t;
		return t;
	};
	_proto._Wait62_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 100;
		return t;
	};
	_proto._Set62_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object62_i();
		return t;
	};
	_proto._Object62_i = function () {
		var t = {};
		this._Object62 = t;
		return t;
	};
	_proto.whole_layout_i = function () {
		var t = new eui.Group();
		this.whole_layout = t;
		t.height = 1080;
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.bg_i(),this.equip_i(),this.l_guo_i(),this._Image1_i(),this.Clock_i(),this.ghost_i(),this.guo_i(),this.l_door_i(),this._Image2_i(),this._Image3_i(),this.door_btn_i(),this.setting_i(),this.mass_i(),this.l_note_i(),this.l_buyshow_i(),this.buy_show_i(),this.l_yes_i(),this.imagine_i(),this.cvs_i(),this.yaoshui_i(),this.med_btn_i(),this.notice_i(),this.users_i(),this.mix_bar_i(),this.communication_i()];
		return t;
	};
	_proto.bg_i = function () {
		var t = new eui.Image();
		this.bg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1080;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "background_png";
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.equip_i = function () {
		var t = new eui.Image();
		this.equip = t;
		t.height = 541;
		t.source = "equip_png";
		t.width = 1419;
		t.x = 23;
		t.y = 538;
		return t;
	};
	_proto.l_guo_i = function () {
		var t = new eui.Image();
		this.l_guo = t;
		t.alpha = 0;
		t.height = 403;
		t.source = "guo_l_png";
		t.width = 618;
		t.x = 334.92;
		t.y = 663.4;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 150;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "talk_inter_png";
		t.width = 1920;
		t.x = 0;
		t.y = 930;
		return t;
	};
	_proto.Clock_i = function () {
		var t = new eui.Group();
		this.Clock = t;
		t.height = 105;
		t.width = 80;
		t.x = 1427;
		t.y = 0;
		return t;
	};
	_proto.ghost_i = function () {
		var t = new eui.Group();
		this.ghost = t;
		t.height = 300;
		t.visible = false;
		t.width = 300;
		t.x = 352;
		t.y = 265;
		t.elementsContent = [this.ghost_pic_i()];
		return t;
	};
	_proto.ghost_pic_i = function () {
		var t = new eui.Image();
		this.ghost_pic = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 284;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "xiaoren_png";
		t.width = 222;
		t.x = 69;
		t.y = 0;
		return t;
	};
	_proto.guo_i = function () {
		var t = new eui.Group();
		this.guo = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 460;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 545;
		t.x = 216.5;
		t.y = 488.29;
		t.elementsContent = [this.factory_i(),this.progress0_i(),this.miss_Num_i()];
		return t;
	};
	_proto.factory_i = function () {
		var t = new eui.Image();
		this.factory = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 452;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "guo_png";
		t.width = 679;
		t.x = 84.5;
		t.y = 133.71;
		return t;
	};
	_proto.progress0_i = function () {
		var t = new eui.ProgressBar();
		this.progress0 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 60.62;
		t.maximum = 150;
		t.minimum = 0;
		t.rotation = 0.22;
		t.skinName = "skins.ProgressBarSkin";
		t.value = 0;
		t.width = 298.67;
		t.x = 253.71;
		t.y = 310.03;
		return t;
	};
	_proto.miss_Num_i = function () {
		var t = new eui.Label();
		this.miss_Num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 71.03;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "混乱值： ";
		t.textColor = 0x000000;
		t.visible = false;
		t.width = 208;
		t.x = -44;
		t.y = 89;
		return t;
	};
	_proto.l_door_i = function () {
		var t = new eui.Image();
		this.l_door = t;
		t.alpha = 0;
		t.height = 350;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "l_door_png";
		t.width = 258;
		t.x = 1562.82;
		t.y = 356;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 347;
		t.source = "black_door_png";
		t.width = 234;
		t.x = 1572;
		t.y = 352;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 349;
		t.source = "open_door_png";
		t.width = 242;
		t.x = 1572;
		t.y = 357.59;
		return t;
	};
	_proto.door_btn_i = function () {
		var t = new eui.Button();
		this.door_btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 347;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 234;
		t.x = 1572;
		t.y = 356.59;
		t.skinName = menuSkin$Skin26;
		return t;
	};
	_proto.setting_i = function () {
		var t = new eui.Button();
		this.setting = t;
		t.anchorOffsetX = 2.51;
		t.anchorOffsetY = 1.26;
		t.height = 68;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 68;
		t.x = 1823.33;
		t.y = 10.32;
		t.skinName = menuSkin$Skin27;
		return t;
	};
	_proto.mass_i = function () {
		var t = new eui.Group();
		this.mass = t;
		t.anchorOffsetY = 0;
		t.height = 124;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 200;
		t.x = 1530;
		t.y = 6.5;
		t.elementsContent = [this.m_num_i()];
		return t;
	};
	_proto.m_num_i = function () {
		var t = new eui.Label();
		this.m_num = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 73.21;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "0";
		t.textColor = 0xffefcc;
		t.width = 173.33;
		t.x = 124.97;
		t.y = 100.53;
		return t;
	};
	_proto.l_note_i = function () {
		var t = new eui.Image();
		this.l_note = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 172;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "l_notes_png";
		t.width = 223;
		t.x = 472.48;
		t.y = 310.84;
		return t;
	};
	_proto.l_buyshow_i = function () {
		var t = new eui.Image();
		this.l_buyshow = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 213;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "l_buyshow_png";
		t.width = 166;
		t.x = 1384;
		t.y = 137.29;
		return t;
	};
	_proto.buy_show_i = function () {
		var t = new eui.Button();
		this.buy_show = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 210;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 160;
		t.x = 1386.5;
		t.y = 135.29;
		t.skinName = menuSkin$Skin28;
		return t;
	};
	_proto.l_yes_i = function () {
		var t = new eui.Image();
		this.l_yes = t;
		t.height = 20;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 20;
		t.x = 1566;
		t.y = 988;
		return t;
	};
	_proto.imagine_i = function () {
		var t = new eui.Group();
		this.imagine = t;
		t.height = 200;
		t.width = 200;
		t.x = 377;
		t.y = 147;
		t.elementsContent = [this.i_img_i(),this.i_imagine_i()];
		return t;
	};
	_proto.i_img_i = function () {
		var t = new eui.Image();
		this.i_img = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "thought_png";
		t.x = 819.53;
		t.y = 290;
		return t;
	};
	_proto.i_imagine_i = function () {
		var t = new eui.Image();
		this.i_imagine = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = -5.64;
		t.height = 141;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "";
		t.width = 127;
		t.x = 890.74;
		t.y = 311.79;
		return t;
	};
	_proto.cvs_i = function () {
		var t = new eui.Group();
		this.cvs = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 654;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 524;
		t.x = 845.53;
		t.y = 137;
		return t;
	};
	_proto.yaoshui_i = function () {
		var t = new eui.Group();
		this.yaoshui = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 1.92;
		t.height = 384;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 865;
		t.x = 88;
		t.y = 97.51;
		t.elementsContent = [this.l_p1_i(),this.l_p2_i(),this.l_p3_i(),this.l_p4_i(),this.l_p5_i(),this.l_p6_i(),this.l_p7_i(),this.l_p8_i(),this.l_piBgeye_i(),this.l_pSkin_i(),this.l_pDye_i(),this.l_pcolar_i(),this.p1_i(),this.p2_i(),this.p3_i(),this.p4_i(),this.p5_i(),this.p6_i(),this.p7_i(),this.p8_i(),this.p_bigeye_i(),this.p_Skin_i(),this.p_dye_i(),this.p_colar_i()];
		return t;
	};
	_proto.l_p1_i = function () {
		var t = new eui.Image();
		this.l_p1 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 85;
		t.x = -35;
		t.y = -61;
		return t;
	};
	_proto.l_p2_i = function () {
		var t = new eui.Image();
		this.l_p2 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 94;
		t.y = -64;
		return t;
	};
	_proto.l_p3_i = function () {
		var t = new eui.Image();
		this.l_p3 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 242;
		t.y = -65;
		return t;
	};
	_proto.l_p4_i = function () {
		var t = new eui.Image();
		this.l_p4 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 667;
		t.y = -65;
		return t;
	};
	_proto.l_p5_i = function () {
		var t = new eui.Image();
		this.l_p5 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = -39;
		t.y = 181;
		return t;
	};
	_proto.l_p6_i = function () {
		var t = new eui.Image();
		this.l_p6 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 193;
		t.source = "l_yao_1_png";
		t.width = 113;
		t.x = 90.5;
		t.y = 183;
		return t;
	};
	_proto.l_p7_i = function () {
		var t = new eui.Image();
		this.l_p7 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 193;
		t.source = "l_yao_1_png";
		t.width = 113;
		t.x = 237;
		t.y = 182.43;
		return t;
	};
	_proto.l_p8_i = function () {
		var t = new eui.Image();
		this.l_p8 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 190;
		t.source = "l_yao_png";
		t.width = 97;
		t.x = 679;
		t.y = 179.84;
		return t;
	};
	_proto.l_piBgeye_i = function () {
		var t = new eui.Image();
		this.l_piBgeye = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 198;
		t.source = "l_bigeye_png";
		t.width = 132;
		t.x = 814;
		t.y = -56;
		return t;
	};
	_proto.l_pSkin_i = function () {
		var t = new eui.Image();
		this.l_pSkin = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 212;
		t.source = "l_skin_png";
		t.width = 112;
		t.x = 989;
		t.y = -58;
		return t;
	};
	_proto.l_pDye_i = function () {
		var t = new eui.Image();
		this.l_pDye = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 106;
		t.source = "l_dye_png";
		t.width = 126;
		t.x = 820;
		t.y = 269.41;
		return t;
	};
	_proto.l_pcolar_i = function () {
		var t = new eui.Image();
		this.l_pcolar = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 154;
		t.source = "l_colar_png";
		t.width = 134;
		t.x = 982;
		t.y = 212;
		return t;
	};
	_proto.p1_i = function () {
		var t = new eui.Image();
		this.p1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p1";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p1_png";
		t.touchEnabled = true;
		t.x = -32;
		t.y = -60;
		return t;
	};
	_proto.p2_i = function () {
		var t = new eui.Image();
		this.p2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p2";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p2_png";
		t.touchEnabled = true;
		t.x = 100;
		t.y = -60;
		return t;
	};
	_proto.p3_i = function () {
		var t = new eui.Image();
		this.p3 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p3";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p3_png";
		t.touchEnabled = true;
		t.x = 247.15;
		t.y = -60;
		return t;
	};
	_proto.p4_i = function () {
		var t = new eui.Image();
		this.p4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p4";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p4_png";
		t.touchEnabled = true;
		t.x = 672.6;
		t.y = -60;
		return t;
	};
	_proto.p5_i = function () {
		var t = new eui.Image();
		this.p5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p5";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p5_png";
		t.touchEnabled = true;
		t.x = -30;
		t.y = 185;
		return t;
	};
	_proto.p6_i = function () {
		var t = new eui.Image();
		this.p6 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p6";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p6_png";
		t.touchEnabled = true;
		t.x = 100;
		t.y = 185;
		return t;
	};
	_proto.p7_i = function () {
		var t = new eui.Image();
		this.p7 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p7";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p7_png";
		t.touchEnabled = true;
		t.x = 246.87;
		t.y = 185;
		return t;
	};
	_proto.p8_i = function () {
		var t = new eui.Image();
		this.p8 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 180;
		t.name = "p8";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "p8_png";
		t.touchEnabled = true;
		t.width = 84;
		t.x = 684.48;
		t.y = 185;
		return t;
	};
	_proto.p_bigeye_i = function () {
		var t = new eui.Image();
		this.p_bigeye = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 140;
		t.source = "p_Bigeye_png";
		t.width = 60;
		t.x = 849.96;
		t.y = -24;
		return t;
	};
	_proto.p_Skin_i = function () {
		var t = new eui.Image();
		this.p_Skin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 140;
		t.source = "p_Skin_png";
		t.width = 60;
		t.x = 1018;
		t.y = -24;
		return t;
	};
	_proto.p_dye_i = function () {
		var t = new eui.Image();
		this.p_dye = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 92;
		t.source = "p_dye_png";
		t.width = 110;
		t.x = 825.4;
		t.y = 276;
		return t;
	};
	_proto.p_colar_i = function () {
		var t = new eui.Image();
		this.p_colar = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 140;
		t.source = "p_Colar_png";
		t.width = 72;
		t.x = 1008;
		t.y = 218;
		return t;
	};
	_proto.med_btn_i = function () {
		var t = new eui.Button();
		this.med_btn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 212;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 260;
		t.x = 446.82;
		t.y = 258.83;
		t.skinName = menuSkin$Skin29;
		return t;
	};
	_proto.notice_i = function () {
		var t = new eui.Group();
		this.notice = t;
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 200;
		t.x = 715;
		t.y = 215;
		t.elementsContent = [this._Image4_i(),this.note_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 348.84;
		t.source = "n30_png";
		t.width = 567.03;
		t.x = -112.42;
		t.y = -57.03;
		return t;
	};
	_proto.note_i = function () {
		var t = new eui.Label();
		this.note = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 77.06;
		t.text = "第 1 天 开始啦！";
		t.textColor = 0xffefcc;
		t.width = 273.94;
		t.x = 43.67;
		t.y = 75.21;
		return t;
	};
	_proto.users_i = function () {
		var t = new eui.Group();
		this.users = t;
		t.height = 200;
		t.width = 200;
		t.x = 1310;
		t.y = 456;
		t.elementsContent = [this.u1_user_i(),this.u2_user_i(),this.u3_user_i(),this.u4_user_i(),this.new_user_i()];
		return t;
	};
	_proto.u1_user_i = function () {
		var t = new eui.Group();
		this.u1_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 50;
		t.x = 257;
		t.y = -60;
		return t;
	};
	_proto.u2_user_i = function () {
		var t = new eui.Group();
		this.u2_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 50;
		t.x = 306;
		t.y = -60;
		return t;
	};
	_proto.u3_user_i = function () {
		var t = new eui.Group();
		this.u3_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 50;
		t.x = 377;
		t.y = -60;
		return t;
	};
	_proto.u4_user_i = function () {
		var t = new eui.Group();
		this.u4_user = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 320;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 51;
		t.x = 456;
		t.y = -60;
		return t;
	};
	_proto.new_user_i = function () {
		var t = new eui.Group();
		this.new_user = t;
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 200;
		t.x = -131.26;
		t.y = -3.41;
		return t;
	};
	_proto.mix_bar_i = function () {
		var t = new eui.ProgressBar();
		this.mix_bar = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.direction = "btt";
		t.height = 156;
		t.maximum = 500;
		t.skinName = "ProgressBarSkin_2";
		t.value = 0;
		t.width = 46;
		t.x = 224;
		t.y = 787;
		return t;
	};
	_proto.communication_i = function () {
		var t = new eui.Group();
		this.communication = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 54;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 128;
		t.x = 276;
		t.y = 952;
		t.elementsContent = [this._Image5_i(),this.dialog_i(),this.ask_panel_i(),this.content_i(),this.somebody_i(),this.yes_i(),this.no_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "com_bgp_png";
		t.x = -276;
		t.y = -71.5;
		return t;
	};
	_proto.dialog_i = function () {
		var t = new eui.Label();
		this.dialog = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 63.33;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "";
		t.textColor = 0x000000;
		t.width = 119.45;
		t.x = -215;
		t.y = -14.999999999999886;
		return t;
	};
	_proto.ask_panel_i = function () {
		var t = new eui.Group();
		this.ask_panel = t;
		t.anchorOffsetX = 0;
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 1400;
		t.x = -223;
		t.y = 0;
		t.elementsContent = [this._Image6_i(),this._Label1_i(),this._Label2_i()];
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.height = 200;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "bg2_jpg";
		t.width = 1400;
		t.x = 1;
		t.y = 0;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "miao";
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "Label";
		t.x = 32;
		t.y = -26;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 92;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 100;
		t.text = "想把他带走吗？";
		t.textColor = 0x000000;
		t.width = 942;
		t.x = 81;
		t.y = 41;
		return t;
	};
	_proto.content_i = function () {
		var t = new eui.Label();
		this.content = t;
		t.anchorOffsetX = -6.62;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 53.61;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "balalalallalla1";
		t.textColor = 0x000000;
		t.width = 1070.64;
		t.x = 237.8;
		t.y = 29.39;
		return t;
	};
	_proto.somebody_i = function () {
		var t = new eui.Label();
		this.somebody = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 87.51;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "name1";
		t.textColor = 0x000000;
		t.width = 126.85;
		t.x = 67.82;
		t.y = 30.39;
		return t;
	};
	_proto.yes_i = function () {
		var t = new eui.Button();
		this.yes = t;
		t.anchorOffsetX = -27.27;
		t.anchorOffsetY = -3.03;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 1197.27;
		t.y = 10.029999999999973;
		t.skinName = menuSkin$Skin30;
		return t;
	};
	_proto.no_i = function () {
		var t = new eui.Button();
		this.no = t;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 1380;
		t.y = 6;
		t.skinName = menuSkin$Skin31;
		return t;
	};
	_proto.tucao_i = function () {
		var t = new eui.Group();
		this.tucao = t;
		t.anchorOffsetY = 0;
		t.height = 96;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 200;
		t.x = 377;
		t.y = 935;
		t.elementsContent = [this._Image7_i(),this.tc_label_i(),this._Label3_i()];
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "com_bgp1_png";
		t.visible = false;
		t.x = -372.5;
		t.y = -51.110000000000014;
		return t;
	};
	_proto.tc_label_i = function () {
		var t = new eui.Label();
		this.tc_label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 150;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "NaN";
		t.textColor = 0x000000;
		t.width = 165;
		t.x = 1024.53;
		t.y = -479;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 46;
		t.text = "顾客";
		t.textColor = 0x000000;
		t.visible = false;
		t.width = 89;
		t.x = -34;
		t.y = 49;
		return t;
	};
	_proto.panel1_i = function () {
		var t = new eui.Group();
		this.panel1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 800;
		t.visible = false;
		t.width = 1200;
		t.x = 289;
		t.y = 113;
		t.elementsContent = [this._Image8_i(),this.show_0_i(),this.show_1_i(),this.show_2_i(),this.show_3_i(),this.show_4_i(),this.show_5_i(),this.fanhui_i()];
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.height = 800;
		t.source = "buy_show_bg_png";
		t.width = 1200;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.show_0_i = function () {
		var t = new eui.Image();
		this.show_0 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 150;
		t.y = 180;
		return t;
	};
	_proto.show_1_i = function () {
		var t = new eui.Image();
		this.show_1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 450;
		t.y = 180;
		return t;
	};
	_proto.show_2_i = function () {
		var t = new eui.Image();
		this.show_2 = t;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 760;
		t.y = 180;
		return t;
	};
	_proto.show_3_i = function () {
		var t = new eui.Image();
		this.show_3 = t;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 150;
		t.y = 450;
		return t;
	};
	_proto.show_4_i = function () {
		var t = new eui.Image();
		this.show_4 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 450;
		t.y = 450;
		return t;
	};
	_proto.show_5_i = function () {
		var t = new eui.Image();
		this.show_5 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.cacheAsBitmap = true;
		t.height = 200;
		t.source = "buypic_bg_png";
		t.width = 250;
		t.x = 760;
		t.y = 450;
		return t;
	};
	_proto.fanhui_i = function () {
		var t = new eui.Button();
		this.fanhui = t;
		t.label = "";
		t.x = 1073;
		t.y = 74;
		t.skinName = menuSkin$Skin32;
		return t;
	};
	_proto.note_panel_i = function () {
		var t = new eui.Group();
		this.note_panel = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 600;
		t.visible = false;
		t.width = 900;
		t.x = 634;
		t.y = 202;
		t.elementsContent = [this._Image9_i(),this.cha_i()];
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "notes_png";
		t.x = -600;
		t.y = -202;
		return t;
	};
	_proto.cha_i = function () {
		var t = new eui.Button();
		this.cha = t;
		t.label = "";
		t.x = 1123.06;
		t.y = -100;
		t.skinName = menuSkin$Skin33;
		return t;
	};
	_proto.tt_i = function () {
		var t = new eui.Group();
		this.tt = t;
		t.height = 200;
		t.visible = false;
		t.width = 200;
		t.x = 842;
		t.y = 802;
		t.elementsContent = [this.test_i(),this.cover0_i()];
		return t;
	};
	_proto.test_i = function () {
		var t = new eui.Image();
		this.test = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "thought_png";
		t.visible = false;
		t.x = 619;
		t.y = -544;
		return t;
	};
	_proto.cover0_i = function () {
		var t = new eui.Image();
		this.cover0 = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1234.33;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "streak_png";
		t.visible = false;
		t.width = 282;
		t.x = 728;
		t.y = 42;
		return t;
	};
	_proto.finish_i = function () {
		var t = new eui.Group();
		this.finish = t;
		t.height = 200;
		t.visible = false;
		t.width = 200;
		t.x = 844;
		t.y = 326;
		t.elementsContent = [this.finish_bg_i(),this.poison_i(),this.finish_l_i(),this.finish_b_i(),this.finish_z_i(),this.finish_f_i()];
		return t;
	};
	_proto.finish_bg_i = function () {
		var t = new eui.Image();
		this.finish_bg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 732;
		t.source = "reward_png";
		t.width = 1156;
		t.x = -346;
		t.y = -174;
		return t;
	};
	_proto.poison_i = function () {
		var t = new eui.Image();
		this.poison = t;
		t.anchorOffsetX = 0;
		t.height = 398;
		t.rotation = 345.16;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "";
		t.width = 271.95;
		t.x = 245;
		t.y = 23;
		return t;
	};
	_proto.finish_l_i = function () {
		var t = new eui.Label();
		this.finish_l = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 39;
		t.text = "Label";
		t.textColor = 0x000000;
		t.width = 307;
		t.x = -166;
		t.y = 23;
		return t;
	};
	_proto.finish_b_i = function () {
		var t = new eui.Button();
		this.finish_b = t;
		t.enabled = true;
		t.height = 120;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 120;
		t.x = 563;
		t.y = -96;
		t.skinName = menuSkin$Skin34;
		return t;
	};
	_proto.finish_z_i = function () {
		var t = new eui.Label();
		this.finish_z = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 204;
		t.text = "Label";
		t.textColor = 0x000000;
		t.width = 238;
		t.x = -152;
		t.y = 77;
		return t;
	};
	_proto.finish_f_i = function () {
		var t = new eui.Label();
		this.finish_f = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 76;
		t.text = "混乱之主";
		t.textColor = 0x000000;
		t.width = 135;
		t.x = -5;
		t.y = 308;
		return t;
	};
	_proto.leader_i = function () {
		var t = new eui.Group();
		this.leader = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 245.45;
		t.visible = false;
		t.width = 287.88;
		t.x = 880;
		t.y = 679;
		t.elementsContent = [this._Image10_i(),this.lead_i(),this.cover_i()];
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 427.63;
		t.source = "n30_png";
		t.width = 570.06;
		t.x = -133.34;
		t.y = -330.3;
		return t;
	};
	_proto.lead_i = function () {
		var t = new eui.Label();
		this.lead = t;
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "miao";
		t.height = 444.24;
		t.text = "欢迎来到你的工作间~ 这是你制作满足女孩们幻想的男性的地方~";
		t.textColor = 0x000000;
		t.width = 293.93;
		t.x = 10;
		t.y = -214.24;
		return t;
	};
	_proto.cover_i = function () {
		var t = new eui.Image();
		this.cover = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 1509.33;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "streak_png";
		t.width = 2523.67;
		t.x = -1454.67;
		t.y = -171.33;
		return t;
	};
	_proto.endpic_i = function () {
		var t = new eui.Image();
		this.endpic = t;
		t.height = 1080;
		t.source = "end_png";
		t.visible = false;
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		return t;
	};
	return menuSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/PanelSkin.exml'] = window.skins.PanelSkin = (function (_super) {
	__extends(PanelSkin, _super);
	function PanelSkin() {
		_super.call(this);
		this.skinParts = ["titleDisplay","moveArea","closeButton"];
		
		this.minHeight = 230;
		this.minWidth = 450;
		this.elementsContent = [this._Image1_i(),this.moveArea_i(),this.closeButton_i()];
	}
	var _proto = PanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(2,2,12,12);
		t.source = "border_png";
		t.top = 0;
		return t;
	};
	_proto.moveArea_i = function () {
		var t = new eui.Group();
		this.moveArea = t;
		t.height = 45;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image2_i(),this.titleDisplay_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "header_png";
		t.top = 0;
		return t;
	};
	_proto.titleDisplay_i = function () {
		var t = new eui.Label();
		this.titleDisplay = t;
		t.fontFamily = "Tahoma";
		t.left = 15;
		t.right = 5;
		t.size = 20;
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.wordWrap = false;
		return t;
	};
	_proto.closeButton_i = function () {
		var t = new eui.Button();
		this.closeButton = t;
		t.bottom = 5;
		t.horizontalCenter = 0;
		t.label = "close";
		return t;
	};
	return PanelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/pause_panel.exml'] = window.pause_panelSkin = (function (_super) {
	__extends(pause_panelSkin, _super);
	var pause_panelSkin$Skin35 = 	(function (_super) {
		__extends(pause_panelSkin$Skin35, _super);
		function pause_panelSkin$Skin35() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin35.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "pause_jixu_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin35;
	})(eui.Skin);

	var pause_panelSkin$Skin36 = 	(function (_super) {
		__extends(pause_panelSkin$Skin36, _super);
		function pause_panelSkin$Skin36() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin36.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "pause_shezi_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin36;
	})(eui.Skin);

	var pause_panelSkin$Skin37 = 	(function (_super) {
		__extends(pause_panelSkin$Skin37, _super);
		function pause_panelSkin$Skin37() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin37.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "pause_fanhui_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin37;
	})(eui.Skin);

	var pause_panelSkin$Skin38 = 	(function (_super) {
		__extends(pause_panelSkin$Skin38, _super);
		function pause_panelSkin$Skin38() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin38.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "fh_yes_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin38;
	})(eui.Skin);

	var pause_panelSkin$Skin39 = 	(function (_super) {
		__extends(pause_panelSkin$Skin39, _super);
		function pause_panelSkin$Skin39() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin39.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "fh_no_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin39;
	})(eui.Skin);

	var pause_panelSkin$Skin40 = 	(function (_super) {
		__extends(pause_panelSkin$Skin40, _super);
		function pause_panelSkin$Skin40() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin40.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "caozuo_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin40;
	})(eui.Skin);

	var pause_panelSkin$Skin41 = 	(function (_super) {
		__extends(pause_panelSkin$Skin41, _super);
		function pause_panelSkin$Skin41() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin41.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "cha_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin41;
	})(eui.Skin);

	var pause_panelSkin$Skin42 = 	(function (_super) {
		__extends(pause_panelSkin$Skin42, _super);
		function pause_panelSkin$Skin42() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = pause_panelSkin$Skin42.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "cha_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return pause_panelSkin$Skin42;
	})(eui.Skin);

	function pause_panelSkin() {
		_super.call(this);
		this.skinParts = ["return_Ask","setting_panel","vanish_returnPanel","vanish_settingPanel","spec_face","vanish_spec","info","continue","setting","return_back","image","fanhui","jixu","return_group","specification","music","music_type","back_btn","setting_group","image0","shuoming_fanhui","shuoming","mainPanel"];
		
		this.height = 1000;
		this.width = 1000;
		this.return_Ask_i();
		this.setting_panel_i();
		this.vanish_returnPanel_i();
		this.vanish_settingPanel_i();
		this.spec_face_i();
		this.vanish_spec_i();
		this.elementsContent = [this.mainPanel_i()];
		
		eui.Binding.$bindProperties(this, ["return_group"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object1,"alpha");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object2,"alpha");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object3,"alpha");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object4,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object5,"alpha");
		eui.Binding.$bindProperties(this, ["setting_group"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object6,"alpha");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object7,"alpha");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object8,"alpha");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object9,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object10,"alpha");
		eui.Binding.$bindProperties(this, ["return_group"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object11,"alpha");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object12,"alpha");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object13,"alpha");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object14,"alpha");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object15,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object16,"alpha");
		eui.Binding.$bindProperties(this, ["setting_group"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object17,"alpha");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object18,"alpha");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object19,"alpha");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object20,"alpha");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object21,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object22,"alpha");
		eui.Binding.$bindProperties(this, ["shuoming"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object23,"alpha");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object24,"alpha");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object25,"alpha");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object26,"alpha");
		eui.Binding.$bindProperties(this, [1],[],this._Object27,"alpha");
		eui.Binding.$bindProperties(this, ["shuoming"],[0],this._TweenItem6,"target");
		eui.Binding.$bindProperties(this, [1],[],this._Object28,"alpha");
		eui.Binding.$bindProperties(this, [0.8],[],this._Object29,"alpha");
		eui.Binding.$bindProperties(this, [0.6],[],this._Object30,"alpha");
		eui.Binding.$bindProperties(this, [0.4],[],this._Object31,"alpha");
		eui.Binding.$bindProperties(this, [0.2],[],this._Object32,"alpha");
		eui.Binding.$bindProperties(this, [0],[],this._Object33,"alpha");
	}
	var _proto = pause_panelSkin.prototype;

	_proto.return_Ask_i = function () {
		var t = new egret.tween.TweenGroup();
		this.return_Ask = t;
		t.items = [this._TweenItem1_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Wait1_i(),this._Set1_i(),this._Wait2_i(),this._Set2_i(),this._Wait3_i(),this._Set3_i(),this._Wait4_i(),this._Set4_i(),this._Wait5_i(),this._Set5_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._Wait4_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._Wait5_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto.setting_panel_i = function () {
		var t = new egret.tween.TweenGroup();
		this.setting_panel = t;
		t.items = [this._TweenItem2_i()];
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait6_i(),this._Set6_i(),this._Wait7_i(),this._Set7_i(),this._Wait8_i(),this._Set8_i(),this._Wait9_i(),this._Set9_i(),this._Wait10_i(),this._Set10_i()];
		return t;
	};
	_proto._Wait6_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set6_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._Wait7_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set7_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._Wait8_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set8_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._Wait9_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set9_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._Wait10_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set10_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto.vanish_returnPanel_i = function () {
		var t = new egret.tween.TweenGroup();
		this.vanish_returnPanel = t;
		t.items = [this._TweenItem3_i()];
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Set11_i(),this._Wait11_i(),this._Set12_i(),this._Wait12_i(),this._Set13_i(),this._Wait13_i(),this._Set14_i(),this._Wait14_i(),this._Set15_i(),this._Wait15_i(),this._Set16_i()];
		return t;
	};
	_proto._Set11_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._Wait11_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set12_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto._Wait12_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set13_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._Wait13_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set14_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._Wait14_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set15_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto._Wait15_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set16_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto.vanish_settingPanel_i = function () {
		var t = new egret.tween.TweenGroup();
		this.vanish_settingPanel = t;
		t.items = [this._TweenItem4_i()];
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Set17_i(),this._Wait16_i(),this._Set18_i(),this._Wait17_i(),this._Set19_i(),this._Wait18_i(),this._Set20_i(),this._Wait19_i(),this._Set21_i(),this._Wait20_i(),this._Set22_i()];
		return t;
	};
	_proto._Set17_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._Wait16_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set18_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._Wait17_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set19_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object19_i();
		return t;
	};
	_proto._Object19_i = function () {
		var t = {};
		this._Object19 = t;
		return t;
	};
	_proto._Wait18_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set20_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object20_i();
		return t;
	};
	_proto._Object20_i = function () {
		var t = {};
		this._Object20 = t;
		return t;
	};
	_proto._Wait19_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set21_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object21_i();
		return t;
	};
	_proto._Object21_i = function () {
		var t = {};
		this._Object21 = t;
		return t;
	};
	_proto._Wait20_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set22_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object22_i();
		return t;
	};
	_proto._Object22_i = function () {
		var t = {};
		this._Object22 = t;
		return t;
	};
	_proto.spec_face_i = function () {
		var t = new egret.tween.TweenGroup();
		this.spec_face = t;
		t.items = [this._TweenItem5_i()];
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Wait21_i(),this._Set23_i(),this._Wait22_i(),this._Set24_i(),this._Wait23_i(),this._Set25_i(),this._Wait24_i(),this._Set26_i(),this._Wait25_i(),this._Set27_i()];
		return t;
	};
	_proto._Wait21_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set23_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object23_i();
		return t;
	};
	_proto._Object23_i = function () {
		var t = {};
		this._Object23 = t;
		return t;
	};
	_proto._Wait22_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set24_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object24_i();
		return t;
	};
	_proto._Object24_i = function () {
		var t = {};
		this._Object24 = t;
		return t;
	};
	_proto._Wait23_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set25_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object25_i();
		return t;
	};
	_proto._Object25_i = function () {
		var t = {};
		this._Object25 = t;
		return t;
	};
	_proto._Wait24_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set26_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object26_i();
		return t;
	};
	_proto._Object26_i = function () {
		var t = {};
		this._Object26 = t;
		return t;
	};
	_proto._Wait25_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set27_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object27_i();
		return t;
	};
	_proto._Object27_i = function () {
		var t = {};
		this._Object27 = t;
		return t;
	};
	_proto.vanish_spec_i = function () {
		var t = new egret.tween.TweenGroup();
		this.vanish_spec = t;
		t.items = [this._TweenItem6_i()];
		return t;
	};
	_proto._TweenItem6_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem6 = t;
		t.paths = [this._Set28_i(),this._Wait26_i(),this._Set29_i(),this._Wait27_i(),this._Set30_i(),this._Wait28_i(),this._Set31_i(),this._Wait29_i(),this._Set32_i(),this._Wait30_i(),this._Set33_i()];
		return t;
	};
	_proto._Set28_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object28_i();
		return t;
	};
	_proto._Object28_i = function () {
		var t = {};
		this._Object28 = t;
		return t;
	};
	_proto._Wait26_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set29_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object29_i();
		return t;
	};
	_proto._Object29_i = function () {
		var t = {};
		this._Object29 = t;
		return t;
	};
	_proto._Wait27_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set30_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object30_i();
		return t;
	};
	_proto._Object30_i = function () {
		var t = {};
		this._Object30 = t;
		return t;
	};
	_proto._Wait28_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set31_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object31_i();
		return t;
	};
	_proto._Object31_i = function () {
		var t = {};
		this._Object31 = t;
		return t;
	};
	_proto._Wait29_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set32_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object32_i();
		return t;
	};
	_proto._Object32_i = function () {
		var t = {};
		this._Object32 = t;
		return t;
	};
	_proto._Wait30_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 50;
		return t;
	};
	_proto._Set33_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object33_i();
		return t;
	};
	_proto._Object33_i = function () {
		var t = {};
		this._Object33 = t;
		return t;
	};
	_proto.mainPanel_i = function () {
		var t = new eui.Group();
		this.mainPanel = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 400;
		t.width = 500;
		t.x = 115;
		t.y = 37;
		t.elementsContent = [this._Image1_i(),this.info_i(),this.continue_i(),this.setting_i(),this.return_back_i(),this.return_group_i(),this.setting_group_i(),this.shuoming_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 400;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "pause_bg_png";
		t.width = 500;
		t.x = -1;
		t.y = -2;
		return t;
	};
	_proto.info_i = function () {
		var t = new eui.Label();
		this.info = t;
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.fontFamily = "hanti";
		t.text = "today is 1 day";
		t.textColor = 0x000000;
		t.width = 294;
		t.x = 92;
		t.y = 62;
		return t;
	};
	_proto.continue_i = function () {
		var t = new eui.Button();
		this.continue = t;
		t.anchorOffsetY = 0;
		t.height = 50;
		t.horizontalCenter = -11;
		t.label = "";
		t.width = 200;
		t.x = 209;
		t.y = 122.5;
		t.skinName = pause_panelSkin$Skin35;
		return t;
	};
	_proto.setting_i = function () {
		var t = new eui.Button();
		this.setting = t;
		t.anchorOffsetY = 0;
		t.height = 50;
		t.horizontalCenter = -11;
		t.label = "";
		t.width = 200;
		t.x = 208;
		t.y = 200;
		t.skinName = pause_panelSkin$Skin36;
		return t;
	};
	_proto.return_back_i = function () {
		var t = new eui.Button();
		this.return_back = t;
		t.height = 50;
		t.horizontalCenter = -10;
		t.label = "";
		t.width = 200;
		t.x = 203;
		t.y = 272.5;
		t.skinName = pause_panelSkin$Skin37;
		return t;
	};
	_proto.return_group_i = function () {
		var t = new eui.Group();
		this.return_group = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.height = 200;
		t.horizontalCenter = 0;
		t.visible = false;
		t.width = 300;
		t.x = 148;
		t.y = 97;
		t.elementsContent = [this.image_i(),this.fanhui_i(),this.jixu_i()];
		return t;
	};
	_proto.image_i = function () {
		var t = new eui.Image();
		this.image = t;
		t.alpha = 1;
		t.anchorOffsetX = 0;
		t.height = 200;
		t.source = "pause_return_png";
		t.width = 300;
		t.x = 0;
		t.y = 1;
		return t;
	};
	_proto.fanhui_i = function () {
		var t = new eui.Button();
		this.fanhui = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 40;
		t.label = "";
		t.width = 60;
		t.x = 70;
		t.y = 125;
		t.skinName = pause_panelSkin$Skin38;
		return t;
	};
	_proto.jixu_i = function () {
		var t = new eui.Button();
		this.jixu = t;
		t.anchorOffsetY = 0;
		t.height = 40;
		t.label = "";
		t.width = 60;
		t.x = 180;
		t.y = 125;
		t.skinName = pause_panelSkin$Skin39;
		return t;
	};
	_proto.setting_group_i = function () {
		var t = new eui.Group();
		this.setting_group = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 300;
		t.horizontalCenter = 0;
		t.visible = false;
		t.width = 400;
		t.x = 73;
		t.y = 38;
		t.elementsContent = [this._Image2_i(),this._Image3_i(),this.specification_i(),this.music_i(),this.music_type_i(),this.back_btn_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 300;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "ps_bg_png";
		t.width = 400;
		t.x = 0.5;
		t.y = -1.5;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 135;
		t.source = "music_set_png";
		t.width = 212;
		t.x = 93;
		t.y = 139.5;
		return t;
	};
	_proto.specification_i = function () {
		var t = new eui.Button();
		this.specification = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 40;
		t.label = "";
		t.width = 149;
		t.x = 126;
		t.y = 59;
		t.skinName = pause_panelSkin$Skin40;
		return t;
	};
	_proto.music_i = function () {
		var t = new eui.CheckBox();
		this.music = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 32;
		t.label = "音乐";
		t.width = 31;
		t.x = 244;
		t.y = 148.5;
		return t;
	};
	_proto.music_type_i = function () {
		var t = new eui.CheckBox();
		this.music_type = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 29;
		t.label = "音效";
		t.width = 29;
		t.x = 244;
		t.y = 230.5;
		return t;
	};
	_proto.back_btn_i = function () {
		var t = new eui.Button();
		this.back_btn = t;
		t.horizontalCenter = 200;
		t.label = "";
		t.x = 151;
		t.y = -23;
		t.skinName = pause_panelSkin$Skin41;
		return t;
	};
	_proto.shuoming_i = function () {
		var t = new eui.Group();
		this.shuoming = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 350;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		t.visible = false;
		t.width = 400;
		t.x = 51;
		t.y = 16;
		t.elementsContent = [this.image0_i(),this._Scroller1_i(),this.shuoming_fanhui_i()];
		return t;
	};
	_proto.image0_i = function () {
		var t = new eui.Image();
		this.image0 = t;
		t.height = 350;
		t.source = "ps_bg_png";
		t.width = 400;
		t.x = 0.5;
		t.y = 0;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 245;
		t.width = 325;
		t.x = 46;
		t.y = 20;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 400;
		t.elementsContent = [this._Label1_i()];
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "hanti";
		t.height = 593;
		t.size = 20;
		t.text = "操作说明： 作为混乱之主的手下，你奉命扮演虚假的爱神制造虚假的“好男人”愚弄人类在人间传递混乱。 每一天点击门开始今天的营业，在规定时间内尽量帮助更多女孩获得她们的“梦中情男”吧～ 单击对应药剂即可把药拿在手上，长按即可往锅里倒入对应药剂，松开鼠标即可停止倒药（会有回摇动作哦owo） 查看不同药剂对应标签可以在游戏里（图）处查看～ 已完成的愿望及其详情都可以在（图）处查看～ 每笔订单完成后便会进行渣值PK随后产生混乱值的奖惩，一天结束后混乱值将决定你是否能保住目前这份工作。 加油吧！小喽啰！";
		t.textColor = 0x000000;
		t.width = 226;
		t.x = 10;
		t.y = 31;
		return t;
	};
	_proto.shuoming_fanhui_i = function () {
		var t = new eui.Button();
		this.shuoming_fanhui = t;
		t.label = "";
		t.x = 350;
		t.y = -12.5;
		t.skinName = pause_panelSkin$Skin42;
		return t;
	};
	return pause_panelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/prebkg.exml'] = window.prebkg = (function (_super) {
	__extends(prebkg, _super);
	function prebkg() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 1080;
		this.width = 1920;
		this.elementsContent = [this._Image1_i()];
	}
	var _proto = prebkg.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "background_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	return prebkg;
})(eui.Skin);generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function (_super) {
	__extends(RadioButtonSkin, _super);
	function RadioButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_disabled_png")
				])
		];
	}
	var _proto = RadioButtonSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "radiobutton_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return RadioButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function (_super) {
	__extends(ScrollerSkin, _super);
	function ScrollerSkin() {
		_super.call(this);
		this.skinParts = ["verticalScrollBar"];
		
		this.minHeight = 20;
		this.minWidth = 20;
		this.elementsContent = [this._Image1_i(),this.verticalScrollBar_i()];
	}
	var _proto = ScrollerSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 80;
		t.right = 2;
		t.source = "huatiao_png";
		t.width = 60;
		t.y = 58;
		return t;
	};
	_proto.verticalScrollBar_i = function () {
		var t = new eui.VScrollBar();
		this.verticalScrollBar = t;
		t.percentHeight = 67;
		t.right = 27;
		t.visible = true;
		t.width = 10;
		t.y = 82;
		return t;
	};
	return ScrollerSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/TextInputSkin.exml'] = window.skins.TextInputSkin = (function (_super) {
	__extends(TextInputSkin, _super);
	function TextInputSkin() {
		_super.call(this);
		this.skinParts = ["textDisplay","promptDisplay"];
		
		this.minHeight = 40;
		this.minWidth = 300;
		this.elementsContent = [this._Image1_i(),this._Rect1_i(),this.textDisplay_i()];
		this.promptDisplay_i();
		
		this.states = [
			new eui.State ("normal",
				[
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("textDisplay","textColor",0xff0000)
				])
			,
			new eui.State ("normalWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
			,
			new eui.State ("disabledWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
		];
	}
	var _proto = TextInputSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(10,10,100,100);
		t.source = "inputText_png";
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.alpha = 0;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.textDisplay_i = function () {
		var t = new eui.EditableText();
		this.textDisplay = t;
		t.fontFamily = "hanti";
		t.height = 35;
		t.left = "10";
		t.right = "10";
		t.size = 30;
		t.textColor = 0x000000;
		t.verticalCenter = "0";
		t.percentWidth = 100;
		return t;
	};
	_proto.promptDisplay_i = function () {
		var t = new eui.Label();
		this.promptDisplay = t;
		t.fontFamily = "hanti";
		t.height = 24;
		t.size = 30;
		t.textColor = 0x000000;
		t.touchEnabled = false;
		t.verticalCenter = -5.5;
		t.percentWidth = 100;
		t.x = 3;
		return t;
	};
	return TextInputSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ToggleSwitchSkin.exml'] = window.skins.ToggleSwitchSkin = (function (_super) {
	__extends(ToggleSwitchSkin, _super);
	function ToggleSwitchSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
		];
	}
	var _proto = ToggleSwitchSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.source = "on_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = -18;
		t.source = "handle_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToggleSwitchSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VScrollBarSkin.exml'] = window.skins.VScrollBarSkin = (function (_super) {
	__extends(VScrollBarSkin, _super);
	function VScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 20;
		this.minWidth = 8;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = VScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 45;
		t.horizontalCenter = 1.5;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "xiaohuakuai_png";
		t.width = 45;
		return t;
	};
	return VScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VSliderSkin.exml'] = window.skins.VSliderSkin = (function (_super) {
	__extends(VSliderSkin, _super);
	function VSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 30;
		this.minWidth = 25;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = VSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_png";
		t.width = 7;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.horizontalCenter = 0;
		t.source = "thumb_png";
		return t;
	};
	return VSliderSkin;
})(eui.Skin);generateEUI.paths['resource/menu/but_setting.exml'] = window.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i()];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 73.21;
		t.source = "setting_btn_png";
		t.width = 76.24;
		t.x = 1593.45;
		t.y = 34.24;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/scene/SceneBegin.exml'] = window.SceneBeginSkin = (function (_super) {
	__extends(SceneBeginSkin, _super);
	function SceneBeginSkin() {
		_super.call(this);
		this.skinParts = ["blockpanel"];
		
		this.height = 1080;
		this.width = 960;
		this.elementsContent = [this.blockpanel_i(),this._Image1_i(),this._Image2_i(),this._Image3_i()];
	}
	var _proto = SceneBeginSkin.prototype;

	_proto.blockpanel_i = function () {
		var t = new eui.Group();
		this.blockpanel = t;
		t.height = 200;
		t.width = 200;
		t.x = 61;
		t.y = 406;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 1080;
		t.source = "bg_jpg";
		t.width = 1920;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "start_btn_png";
		t.x = 166.5;
		t.y = 869.64;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.height = 1080;
		t.source = "bg_jpg";
		t.width = 960;
		t.x = 960;
		t.y = 0;
		return t;
	};
	return SceneBeginSkin;
})(eui.Skin);generateEUI.paths['resource/scene/SceneGame.exml'] = window.SceneGameSkin = (function (_super) {
	__extends(SceneGameSkin, _super);
	var SceneGameSkin$Skin43 = 	(function (_super) {
		__extends(SceneGameSkin$Skin43, _super);
		function SceneGameSkin$Skin43() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = SceneGameSkin$Skin43.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "restart_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return SceneGameSkin$Skin43;
	})(eui.Skin);

	function SceneGameSkin() {
		_super.call(this);
		this.skinParts = ["player","scoreLabel","blockPanel","overScoreLabel","restartBtn","overPanel"];
		
		this.height = 1136;
		this.width = 640;
		this.elementsContent = [this._Image1_i(),this.blockPanel_i(),this.overPanel_i()];
	}
	var _proto = SceneGameSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "bg2_jpg";
		t.top = 0;
		return t;
	};
	_proto.blockPanel_i = function () {
		var t = new eui.Group();
		this.blockPanel = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.player_i(),this.scoreLabel_i()];
		return t;
	};
	_proto.player_i = function () {
		var t = new eui.Image();
		this.player = t;
		t.source = "piece_png";
		t.x = 156;
		t.y = 765.03;
		return t;
	};
	_proto.scoreLabel_i = function () {
		var t = new eui.Label();
		this.scoreLabel = t;
		t.size = 90;
		t.text = "0";
		t.textColor = 0x000000;
		t.x = 129;
		t.y = 128.57;
		return t;
	};
	_proto.overPanel_i = function () {
		var t = new eui.Group();
		this.overPanel = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.elementsContent = [this._Rect1_i(),this._Label1_i(),this.overScoreLabel_i(),this.restartBtn_i()];
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.5;
		t.left = 0;
		t.right = 0;
		t.strokeAlpha = 0.5;
		t.top = 0;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.text = "本次得分";
		t.x = 260;
		t.y = 176.61;
		return t;
	};
	_proto.overScoreLabel_i = function () {
		var t = new eui.Label();
		this.overScoreLabel = t;
		t.anchorOffsetX = 0;
		t.size = 90;
		t.text = "0";
		t.textAlign = "center";
		t.width = 200;
		t.x = 220;
		t.y = 257.19;
		return t;
	};
	_proto.restartBtn_i = function () {
		var t = new eui.Button();
		this.restartBtn = t;
		t.label = "";
		t.x = 165.5;
		t.y = 870.79;
		t.skinName = SceneGameSkin$Skin43;
		return t;
	};
	return SceneGameSkin;
})(eui.Skin);